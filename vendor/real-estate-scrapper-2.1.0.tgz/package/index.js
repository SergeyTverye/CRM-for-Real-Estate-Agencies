'use strict';
const parsers = {
  cian: require('./parsers/cianParser'), avito: require('./parsers/avitoParser'),
  youla: require('./parsers/youlaParser'), yandex: require('./parsers/yandexParser'),
  onrealt: require('./parsers/onRealtParser'), domclick: require('./parsers/domclickParser'),
  mirkvartir: require('./parsers/mirkvartirParser')
};
const { normalizeQuery } = require('./lib/query');
const { ScraperError } = require('./lib/errors');
const { getDistricts, resolveDistricts } = require('./lib/districts');
const { launchBrowserTransport } = require('./lib/browserTransport');
// Sites that reject plain HTTP clients and need a rendered browser session.
// Domclick is served by its public JSON API over plain HTTP.
const BROWSER_SOURCES = ['cian', 'avito'];

class RealEstateScraper {
  constructor(config = {}) {
    this.config = { delay: 1000, maxRetries: 2, timeout: 30000, ...config };
    this.parsers = Object.fromEntries(Object.entries(parsers).map(([name, Parser]) => [name, new Parser({ ...this.config, ...config.sourceConfigs?.[name] })]));
  }
  // Creates a scraper; with { browser: {...} } it launches a private Chromium
  // (optional playwright-core) for sites that block plain HTTP. Call close().
  static async create(config = {}) {
    const { browser: browserOptions, ...rest } = config;
    if (!browserOptions) return new RealEstateScraper(rest);
    const options = browserOptions === true ? {} : browserOptions;
    const sources = options.sources || BROWSER_SOURCES;
    for (const source of sources) if (!Object.hasOwn(parsers, source)) throw new TypeError(`Unknown source: ${source}`);
    const launched = await launchBrowserTransport(options);
    try {
      const sourceConfigs = { ...rest.sourceConfigs };
      for (const source of sources) sourceConfigs[source] = { ...sourceConfigs[source], transport: launched.transport };
      const scraper = new RealEstateScraper({ ...rest, sourceConfigs });
      scraper.browser = launched;
      return scraper;
    } catch (error) { await launched.close().catch(() => {}); throw error; }
  }
  async close() {
    const launched = this.browser; this.browser = null;
    if (launched) await launched.close();
  }
  async [Symbol.asyncDispose]() { await this.close(); }
  getAvailableSources() { return Object.keys(this.parsers); }
  getCapabilities(source) {
    if (source) return this.getParser(source).getCapabilities();
    return Object.fromEntries(this.getAvailableSources().map(s => [s, this.parsers[s].getCapabilities()]));
  }
  getParser(source) {
    if (!Object.hasOwn(this.parsers, source)) throw new TypeError(`Unknown source: ${source}. Available: ${this.getAvailableSources().join(', ')}`);
    return this.parsers[source];
  }
  validate(input) {
    const q = normalizeQuery(input);
    q.sources = [...new Set(q.sources || this.getAvailableSources())];
    q.sources.forEach(s => this.getParser(s));
    for (const s of Object.keys(q.sourceOptions || {})) this.getParser(s);
    return q;
  }
  buildSearchUrls(input = {}) {
    const q = this.validate(input);
    return Object.fromEntries(q.sources.map(s => [s, this.parsers[s].buildSearchUrl(q)]));
  }
  async getDistricts(source, input = {}) {
    return getDistricts(this.getParser(source), normalizeQuery(input));
  }
  variants(q, source) {
    if (!q.types || q.types.length === 1 || this.parsers[source].nativeMultiType) return [q];
    return q.types.map(type => ({ ...q, type, types: [type] }));
  }
  async planSource(q, source) {
    const parser = this.getParser(source); const searches = []; const errors = [];
    try {
      const prepared = await resolveDistricts(parser, q);
      for (const variant of this.variants(prepared, source)) {
        try { searches.push({ source, types: variant.types || [variant.type], url: parser.buildSearchUrl(variant), query: variant }); }
        catch (e) { errors.push({ source, code: e.code || 'SEARCH_FAILED', error: e.message, types: variant.types || [variant.type] }); }
      }
    } catch (e) {
      if (e.code === 'ABORTED' || q.signal?.aborted) throw new ScraperError('ABORTED', 'Search aborted');
      errors.push({ source, code: e.code || 'SEARCH_FAILED', error: e.message });
    }
    return { searches, errors };
  }
  async buildSearchLinks(input = {}) {
    const q = this.validate(input); const searches = []; const errors = [];
    for (const source of q.sources) {
      if (q.signal?.aborted) throw new ScraperError('ABORTED', 'Search aborted');
      const plan = await this.planSource(q, source);
      searches.push(...plan.searches.map(({ query, ...entry }) => entry)); errors.push(...plan.errors);
    }
    return { searches, errors };
  }
  async *searchPages(input = {}) {
    const q = this.validate(input); const seen = new Set(); let count = 0;
    for (const source of q.sources) {
      const parser = this.parsers[source];
      const plan = await this.planSource(q, source);
      for (const error of plan.errors) yield { source, page: q.page, results: [], total: 0, hasNext: null, nextUrl: null, errors: [{ ...error, page: q.page }] };
      let queried = false;
      for (const search of plan.searches) {
        const baseQuery = search.query; const visited = new Set(); const branchSeen = new Set(); let nextUrl; let startPage = baseQuery.page;
        for (let i = 0; i < baseQuery.maxPages; i++) {
          if (q.signal?.aborted) throw new ScraperError('ABORTED', 'Search aborted');
          const pageNumber = startPage + i;
          try {
            if (queried) await parser.delay(parser.config.delay, q.signal);
            const sourceOptions = { ...baseQuery.sourceOptions, [source]: { ...baseQuery.sourceOptions?.[source], ...(nextUrl ? { url: nextUrl } : {}) } };
            const query = { ...baseQuery, page: pageNumber, sourceOptions };
            const url = nextUrl ? parser.assertUrl(nextUrl).toString() : parser.buildSearchUrl(query);
            if (visited.has(url)) break; visited.add(url);
            const page = await parser.searchPage(query, nextUrl);
            if (i === 0) startPage = page.page;
            queried = true;
            let newInBranch = 0;
            for (const item of page.results) if (!branchSeen.has(item.url)) { branchSeen.add(item.url); newInBranch++; }
            const results = page.results.filter(item => {
              const key = source + ':' + item.url;
              if (seen.has(key)) return false; seen.add(key); return true;
            });
            const remaining = q.limit == null ? results.length : q.limit - count;
            const selected = results.slice(0, remaining); count += selected.length;
            yield { ...page, types: search.types, searchUrl: search.url, results: selected, total: selected.length,
              truncated: selected.length < results.length, errors: [] };
            if (q.limit && count >= q.limit) return;
            if (!page.hasNext || !newInBranch) break;
            nextUrl = page.nextUrl;
          } catch (e) {
            if (e.code === 'ABORTED') throw e;
            yield { source, page: pageNumber, results: [], total: 0, hasNext: null, nextUrl: null,
              errors: [{ source, page: pageNumber, code: e.code || 'SEARCH_FAILED', error: e.message, status: e.status, url: e.url }] };
            break;
          }
        }
      }
    }
  }
  async search(input = {}) {
    const query = this.validate(input); const results = []; const errors = []; const pages = [];
    for await (const page of this.searchPages(query)) {
      results.push(...page.results); errors.push(...page.errors);
      const { results: omitted, ...metadata } = page; pages.push(metadata);
    }
    const { signal, ...publicQuery } = query;
    return { query: publicQuery, timestamp: new Date().toISOString(), total: results.length,
      results, errors, pages, partial: errors.length > 0 && results.length > 0 };
  }
  async searchSite(source, input = {}) {
    this.getParser(source);
    return { ...await this.search({ ...input, sources: [source] }), source };
  }
  async searchUrl(source, url, options = {}) {
    return this.searchSite(source, { ...options, sourceOptions: { ...options.sourceOptions,
      [source]: { ...options.sourceOptions?.[source], url } } });
  }
  async report(input = {}, options = {}) {
    return require('./lib/report').buildReport(this, input, options);
  }
}
module.exports = RealEstateScraper;
Object.assign(module.exports, {
  RealEstateScraper, CianParser: parsers.cian, AvitoParser: parsers.avito, YoulaParser: parsers.youla,
  YandexParser: parsers.yandex, OnRealtParser: parsers.onrealt, DomclickParser: parsers.domclick,
  MirkvartirParser: parsers.mirkvartir, BaseParser: require('./parsers/baseParser'), ScraperError,
  createBrowserTransport: require('./lib/browserTransport').createBrowserTransport,
  launchBrowserTransport: require('./lib/browserTransport').launchBrowserTransport,
  renderReport: require('./lib/reportHtml').renderReport,
  renderCsv: require('./lib/reportCsv').renderCsv
});
