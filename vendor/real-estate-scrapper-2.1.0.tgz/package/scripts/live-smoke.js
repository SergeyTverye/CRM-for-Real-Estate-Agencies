'use strict';
const fs = require('node:fs');
const path = require('node:path');
const Scraper = require('..');

async function main() {
  const s = new Scraper({ maxRetries: 0, timeout: 20000, delay: 1000 });
  const queries = [
    ['cian', { city: 'Москва' }],
    ['avito', { city: 'Москва' }],
    ['youla', { sourceOptions: { youla: { url: 'https://youla.ru/' } } }],
    ['yandex', { city: 'Москва' }],
    ['onrealt', { city: 'Москва' }],
    ['domclick', { sourceOptions: { domclick: { url: 'https://domclick.ru/search' } } }],
    ['mirkvartir', { city: 'Москва' }],
    ['yandex', { city: 'Москва', type: 'commercial', deal: 'rent' }],
    ['onrealt', { city: 'Москва', type: 'office', deal: 'rent' }]
  ];
  const checks = [];
  for (const [source, query] of queries) {
    const result = await s.searchSite(source, { ...query, maxPages: 2, limit: 50 });
    const check = { source, query, total: result.total, pages: result.pages.map(p => ({ page: p.page, url: p.url, total: p.total, hasNext: p.hasNext })),
      errors: result.errors, sample: result.results.slice(0, 1).map(({ images, description, ...item }) => item) };
    checks.push(check);
    console.log(`${source} (${query.type || 'flat'}): ${result.total} listings, ${result.pages.length} pages, ${result.errors.map(e => e.code).join(', ') || 'OK'}`);
  }
  const output = path.resolve(__dirname, '../data/live-smoke.json');
  fs.mkdirSync(path.dirname(output), { recursive: true });
  fs.writeFileSync(output, JSON.stringify({ timestamp: new Date().toISOString(), checks }, null, 2));
  console.log(`Report: ${output}`);
}
main().catch(e => { console.error(e); process.exitCode = 1; });
