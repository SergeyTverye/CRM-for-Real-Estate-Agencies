'use strict';
const fs = require('node:fs');
const path = require('node:path');
const axios = require('axios');
const RealEstateScraper = require('..');

async function main(args = process.argv.slice(2)) {
  const positional = args.filter(a => !a.startsWith('--'));
  const query = JSON.parse(fs.readFileSync(path.resolve(positional[0] || path.join(__dirname, '../examples/commercial-report.json')), 'utf8'));
  const directory = path.resolve(positional[1] || path.join(__dirname, '../data/commercial-report'));
  const config = { maxRetries: 0, timeout: 20000, delay: 300 };
  const cdp = args.find(a => a.startsWith('--cdp='))?.slice('--cdp='.length);
  // --browser launches a private Chromium (optional playwright-core); a path
  // selects the executable, otherwise installed Chrome is used.
  const browserArg = args.find(a => a === '--browser' || a.startsWith('--browser='));
  let browser; let scraper;
  if (browserArg) {
    const executablePath = browserArg.includes('=') ? browserArg.slice('--browser='.length) : undefined;
    scraper = await RealEstateScraper.create({ ...config, browser: executablePath ? { executablePath } : { channel: 'chrome' } });
  } else if (cdp) {
    const { chromium } = require('playwright-core');
    browser = await chromium.connectOverCDP(cdp);
    const context = browser.contexts()[0];
    const rendered = RealEstateScraper.createBrowserTransport({ context, timeout: 30000,
      waitUntil: 'domcontentloaded', waitForSelector: '[data-name="CommercialOfferCard"], [data-name="Offers"], form[action*="captcha"], #captcha' });
    config.sourceConfigs = { cian: { transport: request => new URL(request.url).pathname.startsWith('/api/') ? axios(request) : rendered(request) } };
  }
  try {
    scraper ||= new RealEstateScraper(config);
    const report = await scraper.report(query, { detailLimit: 20, candidateLimit: 30 });
    fs.mkdirSync(directory, { recursive: true });
    fs.writeFileSync(path.join(directory, 'report.json'), JSON.stringify(report, null, 2));
    fs.writeFileSync(path.join(directory, 'report.html'), RealEstateScraper.renderReport(report));
    fs.writeFileSync(path.join(directory, 'report.csv'), RealEstateScraper.renderCsv(report));
    console.log(JSON.stringify({ summary: report.summary, sources: report.sources.map(s => ({ source: s.source, status: s.status, matched: s.matched, unknown: s.unknown, errors: s.errors.map(e => e.code) })), output: directory }, null, 2));
    return report;
  } finally {
    // A CDP connection is borrowed; releasing the connection must not close the caller's browser.
    if (browser) await browser.close();
    if (scraper) await scraper.close();
  }
}
if (require.main === module) main().catch(error => { console.error(error); process.exitCode = 1; });
module.exports = main;
