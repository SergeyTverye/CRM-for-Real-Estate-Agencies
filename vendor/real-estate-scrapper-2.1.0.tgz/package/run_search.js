'use strict';
const fs = require('node:fs');
const path = require('node:path');
const RealEstateScraper = require('./index');

async function main(args = process.argv.slice(2)) {
  if (args.includes('--help')) {
    console.log('Usage: npm start -- [query.json] [output.json]');
    console.log('Default: Moscow apartments, Yandex, up to 2 pages / 40 listings.');
    return;
  }
  const query = args[0] ? JSON.parse(fs.readFileSync(path.resolve(args[0]), 'utf8')) : {
    city: 'Москва', type: 'flat', deal: 'sale', sources: ['yandex'], maxPages: 2, limit: 40
  };
  const result = await new RealEstateScraper().search(query);
  const output = path.resolve(args[1] || path.join(__dirname, 'data', 'results_' + Date.now() + '.json'));
  fs.mkdirSync(path.dirname(output), { recursive: true });
  fs.writeFileSync(output, JSON.stringify(result, null, 2), 'utf8');
  console.log(JSON.stringify({ output, total: result.total, errors: result.errors, partial: result.partial }, null, 2));
  if (result.errors.length && !result.total) process.exitCode = 2;
  return result;
}
if (require.main === module) main().catch(error => { console.error(error.message); process.exitCode = 1; });
module.exports = main;
