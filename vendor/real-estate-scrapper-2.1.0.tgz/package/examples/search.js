'use strict';
const RealEstateScraper = require('..'); // In another project: require('real-estate-scrapper')
async function main() {
  const scraper = new RealEstateScraper({ timeout: 30000, delay: 1000, maxRetries: 2 });
  const result = await scraper.search({
    sources: ['cian', 'yandex', 'onrealt'], city: 'Москва', type: 'office', deal: 'rent',
    priceMax: 200000, areaMin: 50, maxPages: 3, limit: 100
  });
  console.log(result.results);
  for (const error of result.errors) console.error(error.source, error.code, error.error);
}
if (require.main === module) main().catch(e => { console.error(e); process.exitCode = 1; });
module.exports = main;
