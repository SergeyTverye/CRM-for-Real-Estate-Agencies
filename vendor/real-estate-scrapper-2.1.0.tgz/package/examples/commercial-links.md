# Прямые ссылки на коммерческий поиск

Пример: **Москва, продажа, районы Арбат ИЛИ Тверской, первый этаж, собственник, 10–100 млн ₽, 50–150 м², торговое ИЛИ ПСН/универсальное ИЛИ офис ИЛИ производство ИЛИ склад**.

- [Открыть поиск на Циане](https://www.cian.ru/cat.php?engine_version=2&deal_type=sale&offer_type=offices&region=1&minprice=10000000&maxprice=100000000&minarea=50&maxarea=150&office_type%5B0%5D=2&office_type%5B1%5D=5&office_type%5B2%5D=1&office_type%5B3%5D=7&office_type%5B4%5D=3&floor_types%5B0%5D=1&is_by_commercial_owner=1&district%5B0%5D=13&district%5B1%5D=20&p=1).
- [Открыть поиск на Яндекс.Недвижимости](https://realty.yandex.ru/moskva/kupit/kommercheskaya-nedvizhimost/?priceMin=10000000&priceMax=100000000&areaMin=50&areaMax=150&commercialType=RETAIL&commercialType=FREE_PURPOSE&commercialType=OFFICE&commercialType=MANUFACTURING&commercialType=WAREHOUSE&floorMin=1&floorMax=1&agents=NO&subLocality=193324&subLocality=12438&page=1).

Отдельный пример **OnRealt: офисы Москвы, первый этаж, собственник, без ограничения по районам и бюджету**:

- [Открыть поиск офисов на OnRealt](https://onrealt.ru/moskva/kypit-ofis?min_floor=1&max_floor=1&counterparty=2).

Ссылки сформированы и параметры проверены 4 ноября 2026. Наличие объявлений меняется; отсутствие результатов допустимо. Площадки могут показывать рекламу и похожие предложения вне выбранных условий. Собственник здесь означает классификацию продавца самой площадкой.

Для генерации актуальных ссылок с другими условиями: `node examples/commercial.js`. Вариант «не подвал/цоколь» задаётся `floorMode: 'notBasement'`, все продавцы — `owner: 'all'`. На Циане режим надземных этажей кодируется `floor_types[0]=2`; на Яндексе — `floorMin=1` без ограничения максимума.
