'use strict';
const fs = require('node:fs');
const path = require('node:path');
const RealEstateScraper = require('..');

const query = {
  city: 'Москва',
  category: 'commercial',
  types: ['retail', 'freePurpose', 'office', 'industrial', 'warehouse'],
  deal: 'sale',
  floorMode: 'first', // 'notBasement' — любой надземный этаж; 'any' — любой этаж.
  owner: 'owner',    // 'all' — собственники и посредники.
  priceMin: 10000000,
  priceMax: 100000000,
  areaMin: 50,
  areaMax: 150,
  districts: ['Арбат', 'Тверской'],
  sources: ['cian', 'yandex'],
  maxPages: 3,
  limit: 100
};

async function main() {
  const scraper = new RealEstateScraper({ maxRetries: 0, timeout: 20000 });
  const plan = await scraper.buildSearchLinks(query);
  const output = path.resolve(__dirname, '../data/commercial-search-links.json');
  fs.mkdirSync(path.dirname(output), { recursive: true });
  fs.writeFileSync(output, JSON.stringify({ query, ...plan }, null, 2));
  for (const search of plan.searches) console.log(`${search.source}: ${search.url}`);
  for (const error of plan.errors) console.error(`${error.source}: ${error.code}: ${error.error}`);
  console.log(`Links saved to ${output}`);
  if (process.argv.includes('--fetch')) console.log(JSON.stringify(await scraper.search(query), null, 2));
}
if (require.main === module) main().catch(e => { console.error(e); process.exitCode = 1; });
module.exports = { query, main };
