'use strict';
// Install Playwright in the host project: npm install playwright
// Install its browser separately: npx playwright install chromium
const { chromium } = require('playwright');
const RealEstateScraper = require('..');

async function main() {
  const [source, url] = process.argv.slice(2);
  if (!source || !url) throw new Error('Usage: node examples/browser.js <source> <native-search-url>');
  const browser = await chromium.launch({ headless: false });
  const context = await browser.newContext({ locale: 'ru-RU' });
  try {
    const transport = RealEstateScraper.createBrowserTransport({ context, waitUntil: 'networkidle' });
    const scraper = new RealEstateScraper({ transport, maxRetries: 0, timeout: 45000 });
    console.log(JSON.stringify(await scraper.searchUrl(source, url, { maxPages: 3, limit: 100 }), null, 2));
  } finally { await context.close(); await browser.close(); }
}
if (require.main === module) main().catch(e => { console.error(e); process.exitCode = 1; });
module.exports = main;
