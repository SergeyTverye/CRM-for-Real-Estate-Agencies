'use strict';
const SourceParser = require('../lib/sourceParser');
const cheerio = require('cheerio');
const { normalizeQuery, location } = require('../lib/query');
const { ScraperError } = require('../lib/errors');
const { extractAssignedJson } = require('../lib/embeddedState');
const { inferPropertyType } = require('../lib/verification');

// Observed in /search/filters/listV2 and /web/1/js/items, 2026-11-04.
const TYPE_IDS = { office: 472642, freePurpose: 472643, retail: 472644, warehouse: 472645, industrial: 472646, building: 473330 };
const API = '/web/1/js/items';
const number = value => { const m = String(value ?? '').replace(/[\s\u00a0\u202f]/g, '').match(/^-?\d+(?:[.,]\d+)?/); return m ? Number(m[0].replace(',', '.')) : null; };
const text = html => cheerio.load(String(html ?? '')).text().trim();
const areaOf = value => { const m = String(value || '').match(/(\d+(?:[.,]\d+)?)\s*(?:м²|м2|кв\.?\s*м\.?)/i); return m ? Number(m[1].replace(',', '.')) : null; };
function floorOf(value) {
  if (value == null || value === '') return { floor: null, floorType: null };
  if (/подвал|цокол|полуподвал/i.test(String(value))) return { floor: null, floorType: 'basement' };
  const floor = number(value); return { floor, floorType: floor == null ? null : floor > 0 ? 'aboveGround' : 'basement' };
}
function districtOf(address) {
  // A street or metro called Арбат is not evidence of a district.
  return String(address || '').match(/(?:^|[,;]\s*)(?:р-н|район)\s+([^,;]+)/i)?.[1]?.trim()
    || String(address || '').match(/(?:^|[,;]\s*)([^,;]+?)\s+район(?:[,;]|$)/i)?.[1]?.trim() || null;
}
function hydration(html) {
  const marker = /window\.__staticRouterHydrationData\s*=\s*JSON\.parse\(\s*("(?:[^"\\]|\\.)*")\s*\)/.exec(html);
  if (marker) { try { return JSON.parse(JSON.parse(marker[1])); } catch { /* schema error is handled by the caller */ } }
  return extractAssignedJson(html, 'window.__staticRouterHydrationData =');
}
function blocked($, url) {
  const visible = $('body').clone(); visible.find('script,style,noscript').remove();
  if (/captcha|доступ ограничен|проблема с IP|проверка безопасности|подтвердите.{0,40}человек|access denied|just a moment/i.test($('title').text() + ' ' + $('h1').text() + ' ' + visible.text().slice(0,2000))
    || $('form[action*="captcha"],#captcha,.SmartCaptcha,#challenge-running').length) throw new ScraperError('ACCESS_BLOCKED', 'Avito returned an access restriction or captcha', { url });
}

class AvitoParser extends SourceParser {
  constructor(config = {}) { super('avito', config); this.nativeMultiType = true; this.splitTypesInReport = false; }
  async fetch(url,options = {}) {
    const u=this.assertUrl(url);
    if (u.pathname===API) {
      const city=u.searchParams.get('locationId')==='637640'?'moskva':null;
      const seed=city?new URL(`/${city}/kommercheskaya_nedvizhimost/${u.searchParams.get('params[536]')==='5546'?'sdam':'prodam'}`,this.baseUrl).toString():this.baseUrl+'/';
      options={...options,browser:{url:seed,...(city?{waitForSelector:'[data-marker="item"]'}:{})},
        headers:{Accept:'application/json','X-Requested-With':'XMLHttpRequest',Referer:seed,...options.headers}};
    }
    try { return await super.fetch(url,options); }
    catch (error) {
      if (error.status === 439) throw new ScraperError('ACCESS_BLOCKED','Avito anti-bot restriction (HTTP 439)',{url,status:439});
      throw error;
    }
  }
  normalizeData(items) {
    return super.normalizeData(items).map((item,index)=>({ ...item,
      address:items[index].address ?? null, description:items[index].description || null,
      ...Object.fromEntries(['priceText','floorType','propertyType','category','deal','sellerType'].map(k=>[k,items[index][k] ?? null])) }));
  }
  reportPlan(q = {}) {
    // District names resolve to Avito IDs via getDistricts() before the request.
    return { localFilters: ['owner', 'floorMin', 'floorMax', ...(q.floorMode === 'notBasement' ? ['floorMode'] : [])] };
  }
  async getDistricts(input = {}) {
    const q=normalizeQuery(input); const o=q.sourceOptions?.avito || {};
    const url=this.buildSearchUrl({city:q.city,citySlug:q.citySlug,category:'commercial',sourceOptions:{avito:{locationId:o.locationId}}});
    this.districtCache ||= new Map();
    const key=new URL(url).searchParams.get('locationId');
    if (this.districtCache.has(key)) return this.districtCache.get(key).map(x=>({...x}));
    let data=await this.fetch(url,{signal:q.signal});
    if (typeof data==='string') {
      const $=cheerio.load(data); if (/^\s*</.test(data)) blocked($,url);
      try { data=JSON.parse(/^\s*</.test(data)?$('body > pre').text():data); }
      catch { throw new ScraperError('DISTRICT_LOOKUP_FAILED','Avito district catalog requires JSON search response',{url}); }
    }
    const links=(data?.seoNavigation?.geo?.tabs || []).flatMap(t=>t.links || []);
    const found=new Map();
    for (const link of links) {
      if (!link.name || !link.url) continue;
      const u=this.assertUrl(link.url); const id=u.searchParams.get('district');
      if (/^\d+$/.test(id || '')) found.set(id,{id:Number(id),name:link.name});
    }
    if (!found.size) throw new ScraperError('DISTRICT_LOOKUP_FAILED','Avito response has no district links',{url});
    this.districtCache.set(key,[...found.values()]); return [...found.values()].map(x=>({...x}));
  }
  buildSearchUrl(input = {}) {
    const q = normalizeQuery(input); const o = q.sourceOptions?.avito || {};
    if (q.category !== 'commercial') return super.buildSearchUrl(q);
    if (o.params != null && (typeof o.params !== 'object' || Array.isArray(o.params))) throw new TypeError('Native params must be an object');
    for (const key of ['floorMin','floorMax']) if (q[key] != null) this.unsupported(`${key} requires report local verification`);
    if (q.floorMode === 'notBasement') this.unsupported('notBasement (including socle) requires report local verification');
    if (q.owner === 'owner') this.unsupported('owner requires report local verification; private seller is not an owner, verified owner excludes unverified owners');
    if ((q.district || q.districts?.length) && !o.districtIds?.length) throw new ScraperError('DISTRICT_RESOLUTION_REQUIRED', 'avito: resolve district names with buildSearchLinks()/search()/report() or provide sourceOptions.avito.districtIds', { source: 'avito' });
    let url = o.url ? this.assertUrl(o.url) : new URL(API, this.baseUrl);
    const api = url.pathname === API;
    if (!api && !url.pathname.includes('/kommercheskaya_nedvizhimost')) this.unsupported('native commercial category URL required');
    if (!api) {
      if (q.types || q.type !== 'commercial' || q.areaMin != null || q.areaMax != null || (q.floorMode && q.floorMode !== 'any')) this.unsupported('additional commercial filters on an encoded native URL cannot be safely merged; use the JSON search URL');
    } else {
      if (!o.url) {
        const loc = location(q, 'avito');
        const id = o.locationId ?? (loc.slug === 'moskva' ? 637640 : null);
        if (!id || !/^\d+$/.test(String(id))) this.unsupported('city needs an Avito locationId (only Moscow=637640 is verified)');
        url.searchParams.set('categoryId', '42'); url.searchParams.set('locationId', id);
        url.searchParams.set('params[536]', q.deal === 'rent' ? '5546' : '5545');
        url.searchParams.set('params[1209]', '13968'); // total price, not price per m²
        url.searchParams.set('localPriority', '0');
      }
      if (!o.url || q.types || q.type !== 'commercial') {
        for (const k of [...url.searchParams.keys()]) if (/^params\[110799\]/.test(k)) url.searchParams.delete(k);
        (q.types || [q.type]).filter(t => t !== 'commercial').forEach((t, i) => {
          if (!TYPE_IDS[t]) this.unsupported(`type=${t}`); url.searchParams.set(`params[110799][${i}]`, TYPE_IDS[t]);
        });
      }
      for (const side of ['Min','Max']) if (q['area'+side] != null) url.searchParams.set(`params[1242][${side === 'Min' ? 'from' : 'to'}]`, q['area'+side]);
      if (q.floorMode === 'first') url.searchParams.set('params[146692][0]', '3235940');
      if (o.districtIds) {
        if (!Array.isArray(o.districtIds) || !o.districtIds.length || o.districtIds.some(x=>!/^\d+$/.test(String(x)))) throw new TypeError('districtIds must contain numeric Avito IDs');
        for (const k of [...url.searchParams.keys()]) if (/^district(?:\[|$)/.test(k)) url.searchParams.delete(k);
        o.districtIds.forEach((id,i)=>url.searchParams.set(`district[${i}]`, id));
      }
    }
    for (const [key,param] of Object.entries({ priceMin:'pmin', priceMax:'pmax', query:'q' })) if (q[key] != null) url.searchParams.set(param,q[key]);
    for (const key of ['metro','sort']) if (q[key] != null) this.unsupported(`${key} requires native params`);
    for (const [key,value] of Object.entries(o.params || {})) {
      url.searchParams.delete(key);
      if (value != null) for (const v of Array.isArray(value) ? value : [value]) {
        if (!['string','number','boolean'].includes(typeof v)) throw new TypeError(`Invalid native param: ${key}`);
        url.searchParams.append(key,String(v));
      }
    }
    if (!o.url || q.page > 1) url.searchParams.set(o.pageParam || 'p',q.page);
    return url.toString();
  }
  cleanUrl(value) { const u = this.assertUrl(value); u.search = ''; u.hash = ''; return u.toString(); }
  itemFromJson(item) {
    const description = text(item.description); const title = item.title || '';
    const badges = Object.values(item.iva || {}).flatMap(x=>Array.isArray(x)?x:[]).flatMap(x=>x.payload?.badges || []);
    const sellerType = badges.some(b=>/^(?:(?:Подтверждённый|Подтвержденный) )?собственник$/i.test(b.title)) ? 'owner' : null;
    return { id: String(item.id), title, url: this.cleanUrl(item.urlPath), price: item.priceDetailed?.hasValue === false ? null : number(item.priceDetailed?.value),
      priceText: item.priceDetailed?.fullString || null, area: areaOf(title), floor: null, floorType: null,
      propertyType: inferPropertyType(title), category: item.categoryId === 42 ? 'commercial' : null,
      deal: ({ sell:'sale', rent:'rent' })[item.realtyInfo?.transactionType] || null, sellerType,
      city: item.location?.name || null, district: districtOf(item.geo?.formattedAddress), address: item.geo?.formattedAddress || null, description,
      images: (item.images || []).map(i=>Object.values(i)[0]).filter(v=>typeof v==='string' && /^https:\/\//.test(v)).map(v=>v.split('?')[0]) };
  }
  assertApplied(data, url) {
    const u = new URL(url); if (u.pathname !== API) return;
    const core = data.searchCore;
    if (!core || !core.params) throw new ScraperError('PARSE_FAILED', 'Avito API lacks applied searchCore filters', { url });
    const wanted = new Map();
    for (const [k,v] of u.searchParams) {
      const m = k.match(/^params\[(\d+)\](?:\[([^\]]+)\])?$/);
      if (m) {
        const key = m[1]; const part = m[2];
        if (part === 'from' || part === 'to') { const obj = wanted.get(key) || {}; obj[part] = Number(v); wanted.set(key,obj); }
        else if (part != null) { const arr = wanted.get(key) || []; arr.push(String(v)); wanted.set(key,arr); }
        else wanted.set(key,String(v));
      }
    }
    const fail = key => { throw new ScraperError('UNSUPPORTED_FILTER', `Avito did not apply requested ${key}; search was not broadened`, {url}); };
    for (const [k,v] of wanted) {
      const actual = core.params[k];
      if (Array.isArray(v)) { if (!Array.isArray(actual) || [...v].sort().join() !== actual.map(String).sort().join()) fail(`params[${k}]`); }
      else if (v && typeof v === 'object') { for (const [side,n] of Object.entries(v)) if (Number(actual?.[side]) !== n || actual?.[side] == null) fail(`params[${k}][${side}]`); }
      else if (String(actual) !== v) fail(`params[${k}]`);
    }
    for (const [k,key] of Object.entries({ categoryId:'categoryId',locationId:'locationId',pmin:'priceMin',pmax:'priceMax',p:'page',owner:'owner',q:'query' })) {
      if (u.searchParams.has(k) && String(core[key]) !== u.searchParams.get(k)) fail(k);
    }
    const ids = [...u.searchParams].filter(([k])=>/^district(?:\[|$)/.test(k)).map(([,v])=>v).sort();
    if (ids.length && ids.join() !== (core.districtId || []).map(String).sort().join()) fail('district');
  }
  assertHtmlFilters(html,requestedUrl,finalUrl) {
    const $ = cheerio.load(html); blocked($,finalUrl);
    const pre = $('body > pre').text();
    if (/^\s*\{/.test(pre)) { let data; try { data=JSON.parse(pre); } catch { throw new ScraperError('PARSE_FAILED','Invalid Avito JSON document',{url:finalUrl}); } this.assertApplied(data,requestedUrl); return; }
    const params = {};
    $('input[checked]').each((_,el)=>{
      const name = $(el).attr('name'); const m=name?.match(/^params\[(\d+)\]$/); if (!m) return;
      if (['536','1209'].includes(m[1])) params[m[1]]=$(el).attr('value');
      else (params[m[1]] ||= []).push($(el).attr('value'));
    });
    const h1=$('h1').text();
    if (/Продажа коммерческой/i.test(h1)) params['536']=5545;
    if (/Аренда коммерческой/i.test(h1)) params['536']=5546;
    const range=marker=>number($(`input[data-marker="${marker}/input"]`).attr('value'));
    params['1242']={from:range('params[1242]-from'),to:range('params[1242]-to')};
    const core={categoryId:/коммерческой недвижимости/i.test(h1)?42:null,locationId:/в\s+Москве/i.test(h1)?637640:null,params,
      priceMin:range('price-from'),priceMax:range('price-to'),page:Number(new URL(finalUrl).searchParams.get('p')||1),
      query:$('input[data-marker="search-form/suggest/input"]').attr('value')||''};
    this.assertApplied({searchCore:core},requestedUrl);
  }
  async searchPage(input = {},pageUrl) {
    const q=normalizeQuery(input); const requested=pageUrl?this.assertUrl(pageUrl).toString():this.buildSearchUrl(q);
    const document=await this.fetch(requested,{signal:q.signal,returnResponse:true}); const finalUrl=this.assertUrl(document.url).toString();
    const api=new URL(requested).pathname===API;
    if (api && typeof document.data==='string' && !/^\s*\{/.test(document.data)) this.assertHtmlFilters(document.data,requested,finalUrl);
    const page=Number(new URL(finalUrl).searchParams.get('p') || new URL(requested).searchParams.get('p') || q.page);
    const parsingUrl=api && (typeof document.data==='object' || /^\s*\{/.test(document.data) || /<pre\b/i.test(document.data))?requested:finalUrl;
    return {...this.parsePage(document.data,parsingUrl,{...q,page}),source:'avito',page,url:finalUrl};
  }
  parseApi(data,url) {
    if (data && !data.catalog && /captcha|access.denied|доступ ограничен|too many requests/i.test(JSON.stringify(data))) throw new ScraperError('ACCESS_BLOCKED','Avito API returned an access restriction',{url});
    if (!data || !Array.isArray(data.catalog?.items) || !Number.isFinite(data.count)) throw new ScraperError('PARSE_FAILED','Avito catalog JSON schema changed',{url});
    this.assertApplied(data,url);
    const records = data.catalog.items.filter(i=>i.type === 'item' && !i.isSimilarToSearch);
    if (!records.length && data.count !== 0) throw new ScraperError('PARSE_FAILED','Avito nonempty catalog contains no usable listings',{url});
    for (const item of records) if (item.id == null || !item.title || !item.urlPath) throw new ScraperError('PARSE_FAILED','Avito listing schema changed',{url});
    const u = new URL(url); const page = Number(u.searchParams.get('p') || data.searchCore?.page || 1);
    const size = data.itemsOnPage; const total = Math.min(data.count, Number.isFinite(data.totalCount) ? data.totalCount : data.count);
    if (data.count > 0 && (!Number.isInteger(size) || size < 1)) throw new ScraperError('PARSE_FAILED','Avito pagination schema changed',{url});
    const hasNext = data.count > 0 && page * size < total;
    u.searchParams.set('p',page+1);
    return { results:this.normalizeData(records.map(i=>this.itemFromJson(i))), sourceTotal:data.count, hasNext, nextUrl:hasNext?u.toString():null };
  }
  parsePage(html, url, query = {}) {
    if (html && typeof html === 'object') return this.parseApi(html,url);
    if (typeof html !== 'string') throw new ScraperError('PARSE_FAILED','Expected Avito HTML or JSON',{url});
    if (/^\s*\{/.test(html)) { try { return this.parseApi(JSON.parse(html),url); } catch(e) { if (e instanceof ScraperError) throw e; throw new ScraperError('PARSE_FAILED','Invalid Avito JSON',{url}); } }
    const $ = cheerio.load(html); blocked($,url);
    const pre = $('body > pre').text(); if (/^\s*\{/.test(pre)) return this.parsePage(pre,url,query);
    const state = hydration(html)?.loaderData?.['catalog-or-main-or-item'];
    const catalog = state?.catalog || state?.buyerCatalog;
    if (catalog?.catalog?.items) return this.parseApi(catalog,url);
    const results = []; const seen = new Set();
    $('[data-marker="item"]').each((_,el)=>{
      const card = $(el); const link = card.find('a[data-marker="item-title"]').first();
      const title = link.text().trim(); const href = link.attr('href');
      if (!title || !href) throw new ScraperError('PARSE_FAILED','Avito listing title/link missing',{url});
      const itemUrl = this.cleanUrl(href); if (seen.has(itemUrl)) return; seen.add(itemUrl);
      const priceText = card.find('[data-marker="item-price"]').first().text().trim() || null;
      const address = card.find('[data-marker="item-address"] p').map((_,p)=>$(p).text().trim()).get().filter(Boolean).join(', ') || card.find('[data-marker="item-address"]').text().trim() || null;
      const desc = card.find('[itemprop="description"],[class*="description"],[class*="bottomBlock"] > div > p').first().text().trim()
        || card.find('p').map((_,p)=>$(p).text().trim()).get().sort((a,b)=>b.length-a.length)[0] || null;
      const alt = card.find('img[itemprop="image"]').first().attr('alt');
      const city = alt?.startsWith(title+', ') ? alt.slice(title.length+2).trim() : null;
      const classification = card.find('[data-marker*="badge"]').map((_,e)=>$(e).text().trim()).get();
      results.push({ id:card.attr('data-item-id') || card.attr('data-id') || new URL(itemUrl).pathname.match(/_(\d+)$/)?.[1] || null,
        title,url:itemUrl,price:this.parsePrice(card.find('[itemprop="price"]').attr('content') || priceText),priceText,
        area:areaOf(title),floor:null,floorType:null,propertyType:inferPropertyType(title),category:itemUrl.includes('/kommercheskaya_nedvizhimost/')?'commercial':null,
        deal:/^(?:Продам|Продажа)(?:\s|[,;]|$)/iu.test(title)?'sale':/^(?:Сдам|Аренда)(?:\s|[,;]|$)/iu.test(title)?'rent':null,
        sellerType:classification.some(t=>/^(?:(?:Подтверждённый|Подтвержденный) )?собственник$/i.test(t))?'owner':null,
        city,district:districtOf(address),address,description:desc,
        images:[...new Set(card.find('img[itemprop="image"]').map((_,e)=>$(e).attr('src')).get().filter(v=>/^https:\/\//.test(v)).map(v=>v.split('?')[0]))] });
    });
    const visible = $('body').clone(); visible.find('script,style,noscript').remove();
    if (!results.length && !/ничего не найдено|объявлений не найдено|нет объявлений|найдено\s+0\b/i.test(visible.text())) throw new ScraperError('PARSE_FAILED','Avito returned no cards or explicit empty marker',{url});
    const current = new URL(url); const page = Number(current.searchParams.get('p') || query.page || 1);
    let nextUrl = null;
    $('a[data-marker^="pagination-button/"],a[rel="next"]').each((_,el)=>{
      if (nextUrl || $(el).attr('aria-disabled') === 'true') return;
      const href = $(el).attr('href'); if (!href) return;
      const next = this.assertUrl(href); if (next.pathname !== current.pathname || Number(next.searchParams.get('p')) !== page+1) return;
      next.searchParams.delete('context'); nextUrl = next.toString();
    });
    return { results:this.normalizeData(results),hasNext:Boolean(nextUrl),nextUrl };
  }
  async fetchDetails(item,q = {}) {
    const url = this.cleanUrl(item.url); const html = await this.fetch(url,{signal:q.signal});
    if (typeof html !== 'string') throw new ScraperError('PARSE_FAILED','Expected Avito detail HTML',{url});
    const $ = cheerio.load(html); blocked($,url);
    const b = hydration(html)?.loaderData?.['catalog-or-main-or-item']?.buyerItem; const i = b?.item;
    if (!i || !i.id || !i.title || !Array.isArray(b.paramsBlock?.items)) throw new ScraperError('PARSE_FAILED','Avito detail hydration schema changed',{url});
    if (String(i.id) !== String(item.id)) throw new ScraperError('PARSE_FAILED','Avito detail ID differs from requested listing',{url});
    if (i.isActive === false || i.isDeleted || i.isArchived) throw new ScraperError('LISTING_UNAVAILABLE','Avito listing is unavailable',{url});
    const attr = name => b.paramsBlock.items.find(x=>x.title === name)?.description;
    const crumb = (i.breadcrumbs || []).map(x=>x.name);
    const kind = crumb.map(inferPropertyType).filter(Boolean).pop() || item.propertyType || null;
    const labels = [...(i.badgeBar?.badges || []),...(i.sellerBadgeBar?.badges || []),...(i.sellerBadgeBar?.iconsBadges || [])].map(x=>x.title);
    const sellerType = labels.some(t=>/^(?:(?:Подтверждённый|Подтвержденный) )?собственник$/i.test(t))?'owner':item.sellerType || null;
    return this.normalizeData([{...item,id:String(i.id),title:i.title,url:this.cleanUrl(i.url || url),price:number(i.price),priceText:text(i.formattedPrice?.formatedString) || item.priceText,
      area:areaOf(attr('Общая площадь')),...floorOf(attr('Этаж')),propertyType:kind,category:i.categoryId === 42?'commercial':null,
      deal:crumb.includes('Продам')?'sale':crumb.includes('Сдам')?'rent':null,sellerType,
      city:i.location?.name || null,address:i.address || null,district:districtOf(i.address),description:text(i.description),
      images:(i.imageUrls || []).map(x=>Object.values(x)[0]).filter(x=>typeof x==='string'&&/^https:\/\//.test(x)).map(x=>x.split('?')[0])}])[0];
  }
  getCapabilities() {
    return { source:'avito',nativeUrl:true,nativeParams:true,pagination:'p',nativeMultiType:true,
      unifiedFilters:['types','deal','priceMin','priceMax','areaMin','areaMax','query'],
      localFilters:['districts','owner','floorMin','floorMax','floorMode'],
      note:'Commercial JSON catalog; applied filters are checked against searchCore. First floor is native; notBasement and ownership require report verification. Moscow locationId=637640 verified; other cities require sourceOptions.avito.locationId or native URL. Browser HTML transport supported.' };
  }
}
module.exports = AvitoParser;
