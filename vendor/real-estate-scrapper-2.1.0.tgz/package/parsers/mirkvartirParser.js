'use strict';
const cheerio = require('cheerio');
const SourceParser = require('../lib/sourceParser');
const { normalizeQuery } = require('../lib/query');
const { ScraperError } = require('../lib/errors');
const { extractAssignedJson } = require('../lib/embeddedState');

// Observed in the site's own listing URLs and search state (2026-11-04).
const commercialTypes = { office: 101, warehouse: 102, retail: 103, freePurpose: 104 };
const numericFilters = { priceMin: 'priceFrom', priceMax: 'priceTo', areaMin: 'areaFrom', areaMax: 'areaTo', floorMin: 'floorFrom', floorMax: 'floorTo' };
const commercialHost = host => ['cre.mirkvartir.ru', 'arendacre.mirkvartir.ru'].includes(host);
const text = ($, el) => $(el).text().replace(/\s+/g, ' ').trim();
const normalizeDistrict = name => name.toLocaleLowerCase('ru-RU').replace(/ё/g, 'е').trim()
  .replace(/^(?:р-н|район)\s+|\s+(?:район|р-н)$/g, '').replace(/\s+/g, ' ');

// Next RSC frames contain JSON string fragments, not executable application state.
// Join fragments before reading an object: a key or quoted value can span scripts.
function readFlight($) {
  return $('script:not([src])').map((_, el) => {
    const frame = extractAssignedJson($(el).text(), 'self.__next_f.push(');
    return frame?.[0] === 1 && typeof frame[1] === 'string' ? frame[1] : '';
  }).get().join('');
}

function listingDistricts(flight) {
  const byId = new Map();
  for (const line of flight.split('\n')) {
    const match = line.match(/^[\da-f]+:([\[{].*)$/);
    if (!match) continue;
    let root; try { root = JSON.parse(match[1]); } catch { continue; }
    const stack = [root];
    while (stack.length) {
      const node = stack.pop();
      if (!node || typeof node !== 'object') continue;
      if (/^\d+$/.test(String(node.cardId)) && typeof node.okrugDistrictName === 'string') {
        const district = node.okrugDistrictName.split('|')[1]?.replace(/^район\s+|\s+район$/gi, '').trim();
        if (district && !/^(?:none|null|undefined)$/i.test(district)) {
          const key = String(node.cardId);
          if (!byId.has(key)) byId.set(key, district);
          else if (byId.get(key) !== district) byId.set(key, null);
        }
      }
      for (const value of Object.values(node)) if (value && typeof value === 'object') stack.push(value);
    }
  }
  return byId;
}

class MirkvartirParser extends SourceParser {
  constructor(config = {}) {
    super('mirkvartir', config);
    this.nativeMultiType = false;
    this.splitTypesInReport = true;
  }

  reportPlan(q) {
    return { localFilters: [] };
  }

  async getDistrictCatalog(input = {}) {
    const q = normalizeQuery(input);
    const o = q.sourceOptions?.mirkvartir || {};
    // Fetch the city-wide public form, independently of type, deal, districts,
    // price and page. Sale/rent use the same local district IDs.
    const lookup = new URL(this.buildSearchUrl({ city: q.city, category: 'commercial', type: 'office', deal: 'sale',
      sourceOptions: { mirkvartir: { ...(o.url ? { url: o.url } : {}), ...(o.locationIds ? { locationIds: o.locationIds } : {}),
        ...(o.params?.locationIds ? { params: { locationIds: o.params.locationIds } } : {}) } } }));
    const scope = o.locationIds || o.params?.locationIds || lookup.searchParams.get('locationIds');
    lookup.search = '';
    if (scope) { lookup.pathname = '/listing/'; lookup.searchParams.set('locationIds', scope); }
    lookup.searchParams.set('types', '101');
    const key = lookup.origin + lookup.pathname + '|' + (scope || normalizeDistrict(q.city || ''));
    this.districtCatalogCache ||= new Map();
    if (!this.districtCatalogCache.has(key)) {
      const pending = (async () => {
        const html = await this.fetch(lookup.toString(), { signal: q.signal });
        if (typeof html !== 'string') throw new ScraperError('DISTRICT_LOOKUP_FAILED', 'Мир Квартир: expected public district catalogue HTML');
        const $ = cheerio.load(html);
        if (/captcha|доступ ограничен|проверка безопасности|access denied/i.test($('title,h1').text()) || $('#captcha,.SmartCaptcha,form[action*="captcha"]').length) throw new ScraperError('ACCESS_BLOCKED', 'Мир Квартир: district catalogue returned a captcha');
        const popup = extractAssignedJson(readFlight($), '"districtsPopup":');
        if (!Array.isArray(popup?.blocks)) throw new ScraperError('DISTRICT_LOOKUP_FAILED', 'Мир Квартир: public districtsPopup catalogue missing or changed');
        const catalog = new Map();
        for (const block of popup.blocks) for (const group of block.linkGroups || []) for (const link of group.locationLinks || []) {
          if (link.id?.category !== 'MK_District' || !/^\d+$/.test(String(link.id.localId)) || typeof link.name !== 'string' || !link.name.trim()) continue;
          const id = String(link.id.localId); const name = link.name.trim();
          catalog.set(id + ':' + normalizeDistrict(name), { id, name });
        }
        if (!catalog.size) throw new ScraperError('DISTRICT_LOOKUP_FAILED', 'Мир Квартир: no public district entries for the selected city');
        return [...catalog.values()];
      })();
      this.districtCatalogCache.set(key, pending);
      pending.catch(() => { if (this.districtCatalogCache.get(key) === pending) this.districtCatalogCache.delete(key); });
    }
    return (await this.districtCatalogCache.get(key)).map(item => ({ ...item }));
  }

  // Public hook for lib/districts.js: returns deduplicated local IDs as strings,
  // e.g. ['81', '164']; callers put them in sourceOptions.mirkvartir.districtIds.
  async resolveDistrictIds(names, q = {}) {
    if (!Array.isArray(names) || !names.length || names.some(name => typeof name !== 'string' || !name.trim())) throw new TypeError('District names must be a nonempty array of names');
    const catalog = await this.getDistrictCatalog(q);
    const ids = names.map(name => {
      const matches = catalog.filter(item => normalizeDistrict(item.name) === normalizeDistrict(name));
      const unique = [...new Set(matches.map(item => item.id))];
      if (unique.length !== 1) throw new ScraperError('DISTRICT_NOT_FOUND', `mirkvartir: district '${name}' ${unique.length ? 'is ambiguous' : 'was not found'} in the selected city`, { source: this.sourceName });
      return unique[0];
    });
    return [...new Set(ids)];
  }

  async searchPage(input = {}, pageUrl) {
    const q = normalizeQuery(input);
    const url = pageUrl ? this.assertUrl(pageUrl).toString() : this.buildSearchUrl(q);
    if (!commercialHost(new URL(url).hostname)) return super.searchPage(q, pageUrl);
    const param = q.sourceOptions?.mirkvartir?.pageParam || this.pageParam;
    const requestedPage = Number(new URL(url).searchParams.get(param) || q.page);
    let doc = await this.fetch(url, { signal: q.signal, returnResponse: true });
    let final = this.assertUrl(doc.url);
    // /listing/ redirects to an SEO route and drops p. Resolve that route,
    // then request the intended page on it rather than returning page one.
    if (requestedPage > 1 && Number(final.searchParams.get(param) || 1) !== requestedPage) {
      final.searchParams.set(param, requestedPage);
      doc = await this.fetch(final.toString(), { signal: q.signal, returnResponse: true });
      final = this.assertUrl(doc.url);
      if (Number(final.searchParams.get(param) || 1) !== requestedPage) throw new ScraperError('PARSE_FAILED', 'Мир Квартир: pagination redirected to a different page', { url: final.toString() });
    }
    if (!commercialHost(final.hostname)) throw new ScraperError('PARSE_FAILED', 'Мир Квартир: commercial search redirected outside the commercial section', { url: final.toString() });
    const effectivePage = Number(final.searchParams.get(param) || 1);
    return { ...this.parsePage(doc.data, final.toString(), { ...q, page: effectivePage }), source: this.sourceName, page: effectivePage, url: final.toString() };
  }

  buildSearchUrl(input = {}) {
    const q = normalizeQuery(input);
    if (q.category !== 'commercial') return super.buildSearchUrl(q);
    const o = q.sourceOptions?.mirkvartir || {};
    if (o.params != null && (typeof o.params !== 'object' || Array.isArray(o.params))) throw new TypeError('Native params must be an object');
    if (q.types?.length > 1) this.unsupported('multiple types require separate searches (buildSearchLinks / report)');
    // The site's commercial selector offers only office, warehouse, retail and
    // free-purpose premises; other uses are not published as a category.
    if (q.type !== 'commercial' && !commercialTypes[q.type]) throw new ScraperError('NOT_APPLICABLE', `mirkvartir: the site has no "${q.type}" commercial category (only office, warehouse, retail, free purpose)`, { source: 'mirkvartir' });
    for (const k of ['rooms', 'metro', 'sort', 'query']) if (q[k] != null) this.unsupported(`${k} has no verified commercial mapping`);
    if ((q.district || q.districts?.length) && !o.districtIds?.length) throw new ScraperError('DISTRICT_RESOLUTION_REQUIRED', 'mirkvartir: resolve district names with resolveDistrictIds(names, query) and supply sourceOptions.mirkvartir.districtIds');
    if (o.districtIds != null && (!Array.isArray(o.districtIds) || !o.districtIds.length || o.districtIds.some(id => !/^[1-9]\d*$/.test(String(id))))) throw new TypeError('mirkvartir districtIds must be a nonempty array of positive numeric local district IDs');
    let url;
    if (o.url) {
      url = this.assertUrl(o.url);
      if (!commercialHost(url.hostname)) this.unsupported('commercial URL must use cre.mirkvartir.ru or arendacre.mirkvartir.ru');
    } else {
      url = new URL(`https://${q.deal === 'rent' ? 'arendacre' : 'cre'}.mirkvartir.ru/listing/`);
      // Region IDs used by other sources are not Mir Kvartir IDs.
      const city = q.city?.toLowerCase();
      if (o.locationIds) url.searchParams.set('locationIds', String(o.locationIds));
      else if (city === 'москва') url.searchParams.set('locationIds', 'MK_Region|77');
      else this.unsupported('location requires a verified native URL or sourceOptions.mirkvartir.locationIds (automatic mapping currently covers Москва)');
    }
    for (const [key, value] of Object.entries(o.params || {})) {
      url.searchParams.delete(key);
      if (value == null) continue;
      for (const v of Array.isArray(value) ? value : [value]) {
        if (!['string', 'number', 'boolean'].includes(typeof v)) throw new TypeError(`Invalid native param: ${key}`);
        url.searchParams.append(key, String(v));
      }
    }
    // Explicit unified constraints take precedence over conflicting raw params.
    if (o.districtIds?.length) {
      const scope = o.locationIds || url.searchParams.get('locationIds') || (q.city?.toLowerCase() === 'москва' ? 'MK_Region|77' : null);
      if (!/^MK_(?:Region|Town)\|\d+$/.test(scope || '')) this.unsupported('districts require a native city/region locationIds scope');
      url.pathname = '/listing/'; url.searchParams.set('locationIds', scope);
      url.searchParams.set('districts', [...new Set(o.districtIds.map(String))].join(','));
    }
    if (commercialTypes[q.type]) url.searchParams.set('types', commercialTypes[q.type]);
    for (const [key, param] of Object.entries(numericFilters)) if (q[key] != null) url.searchParams.set(param, q[key]);
    if (q.floorMode === 'first') { url.searchParams.set('floorFrom', 1); url.searchParams.set('floorTo', 1); }
    if (q.floorMode === 'notBasement') url.searchParams.set('floorFrom', Math.max(1, q.floorMin ?? 1));
    if (q.owner === 'owner') url.searchParams.set('onlyUser', 'true');
    if (q.page > 1 || !o.url) url.searchParams.set(o.pageParam || this.pageParam, q.page);
    return this.assertUrl(url.toString()).toString();
  }

  parsePage(html, url, query = {}) {
    // Preserve the existing residential parser and its verified fixtures.
    if (!commercialHost(new URL(url).hostname)) return super.parsePage(html, url, query);
    if (typeof html !== 'string') throw new ScraperError('INVALID_RESPONSE', 'Expected Mir Kvartir HTML', { url });
    const $ = cheerio.load(html);
    const districtsById = listingDistricts(readFlight($));
    const visible = $('body').clone(); visible.find('script,style,noscript').remove();
    if (/captcha|access denied|just a moment|доступ ограничен|проверка безопасности|подтвердите.{0,40}человек|проверка браузера/i.test($('title').text() + ' ' + visible.text()) || $('form[action*="captcha"],#captcha,.SmartCaptcha,#challenge-running').length) {
      throw new ScraperError('ACCESS_BLOCKED', 'Мир Квартир: captcha or access restriction', { url });
    }
    const items = []; const seen = new Set(); let recognized = 0;
    $('article').each((_, el) => {
      const card = $(el);
      const link = card.find('a[href]').filter((_, a) => {
        try { const u = new URL($(a).attr('href'), url); return commercialHost(u.hostname) && /^\/\d+\/$/.test(u.pathname); } catch { return false; }
      }).first();
      // Recommendations for apartments may occur inside a commercial list.
      if (!link.length) return;
      recognized++;
      const title = text($, card.find('.yaBzb').first());
      if (!title) throw new ScraperError('PARSE_FAILED', 'Мир Квартир: commercial card title markup changed', { url });
      if (card.find('[data-achived="true"]').length || /Архив/.test(card.find('.Jkcq0').text())) return;
      const itemUrl = this.assertUrl(new URL(link.attr('href'), url).toString()); itemUrl.search = ''; itemUrl.hash = '';
      if (seen.has(itemUrl.toString())) return; seen.add(itemUrl.toString());
      const params = text($, card.find('.xP8wA').first()) || title;
      const area = params.match(/(\d+(?:[.,]\d+)?)\s*м[²2]/i);
      const floorMatch = params.match(/(-?\d+)\s*\/\s*\d+\s*этаж/i);
      const floor = floorMatch ? Number(floorMatch[1]) : null;
      const basement = /подвал|цокол/i.test(params);
      const priceText = text($, card.find('._NrqU > strong').first());
      if (!priceText) throw new ScraperError('PARSE_FAILED', 'Мир Квартир: commercial card price markup changed', { url });
      const addressEl = card.find('.kpMfk').first();
      const seller = text($, card.find('.Jkcq0').first());
      // Names, isUser and company flags are not a seller classification.
      const sellerType = /Собственник/i.test(seller) ? 'owner' : /Агентство|Агент|Посредник/i.test(seller) ? 'agent' : null;
      const type = /^Офис(?:\s|,|$)/i.test(params) ? 'office' : /^Склад/i.test(params) ? 'warehouse'
        : /^Торговое помещение/i.test(params) ? 'retail' : /^(?:ПСН|Помещение свободного назначения)/i.test(params) ? 'freePurpose'
          : /^Производствен/i.test(params) ? 'industrial' : /^Здание/i.test(params) ? 'building' : null;
      const address = text($, addressEl) || null;
      const district = address?.match(/(?:^|,\s*)(?:район\s+([^,]+)|([^,]+?)\s+район)(?:,|$)/i);
      const images = card.find('img').map((_, img) => $(img).attr('src') || $(img).attr('data-src')).get().map(src => {
        try { const u = new URL(src, url); return /^https?:$/.test(u.protocol) ? u.toString() : null; } catch { return null; }
      }).filter(Boolean);
      items.push({ id: itemUrl.pathname.split('/')[1], title, url: itemUrl.toString(), price: this.parsePrice(priceText), priceText,
        area: area ? Number(area[1].replace(',', '.')) : null, floor,
        floorType: basement || floor != null && floor <= 0 ? 'basement' : floor != null ? 'aboveGround' : null,
        propertyType: type, category: 'commercial', deal: itemUrl.hostname === 'arendacre.mirkvartir.ru' ? 'rent' : 'sale',
        sellerType, city: text($, addressEl.find('a').first()) || null, district: districtsById.get(itemUrl.pathname.split('/')[1]) || (district ? (district[1] || district[2]).trim() : null),
        address, description: text($, card.find('.wRlHb').first()) || null, images: [...new Set(images)] });
    });
    const totalText = text($, $('.zJW8g > span').first()) + ' ' + $('title').text();
    const totalMatch = totalText.match(/(?:—\s*)?(\d[\d\s\u00a0]*)\s+объявлен/i);
    const sourceTotal = totalMatch ? Number(totalMatch[1].replace(/\s/g, '')) : undefined;
    const empty = /ничего не найдено|объявлений не найдено|нет объявлений/i.test($('h1,h2,.empty-result,.zJW8g > span').text()) || sourceTotal === 0;
    if (!recognized && !empty) throw new ScraperError('PARSE_FAILED', 'Мир Квартир: no commercial cards or explicit empty marker (markup changed or wrong section)', { url });
    const current = new URL(url); const param = query.sourceOptions?.mirkvartir?.pageParam || this.pageParam;
    const page = Number(current.searchParams.get(param) || query.page || 1);
    let nextUrl = null;
    $('a[href]').each((_, el) => {
      if (nextUrl) return;
      try {
        const next = this.assertUrl(new URL($(el).attr('href'), url).toString());
        if (next.hostname !== current.hostname || next.pathname !== current.pathname || Number(next.searchParams.get(param)) !== page + 1) return;
        // Keep constraints if a site's pagination link happens to omit them.
        for (const key of new Set(current.searchParams.keys())) if (key !== param && !next.searchParams.has(key)) {
          for (const value of current.searchParams.getAll(key)) next.searchParams.append(key, value);
        }
        nextUrl = next.toString();
      } catch { /* Ignore unrelated and external links. */ }
    });
    const results = this.normalizeData(items).map((item, i) => ({ ...item, address: items[i].address, description: items[i].description }));
    return { results, hasNext: Boolean(nextUrl), nextUrl, ...(sourceTotal == null ? {} : { sourceTotal }) };
  }

  getCapabilities() {
    return { ...super.getCapabilities(), nativeMultiType: false, splitTypesInReport: true,
      commercial: true, commercialTypes: Object.keys(commercialTypes), deals: ['sale', 'rent'],
      unifiedFilters: ['city', 'category', 'type', 'types', 'deal', ...Object.keys(numericFilters), 'floorMode', 'owner', 'districts'],
      localFilters: [], automaticCities: ['Москва'],
      note: 'Commercial: cre/arendacre; OR types split into searches. Districts resolve from the public city catalogue to comma-separated native districts IDs (OR). Industrial/building have no native category. Other locations require a native URL/locationIds. Residential behavior is inherited.' };
  }
}
module.exports = MirkvartirParser;
