'use strict';
const SourceParser = require('../lib/sourceParser');
const { normalizeQuery } = require('../lib/query');
const { ScraperError } = require('../lib/errors');
const { extractAssignedJson } = require('../lib/embeddedState');
const { inferFloor } = require('../lib/verification');
const cheerio = require('cheerio');

const MOSCOW = '1d1463ae-c80f-4d19-9331-a1b68a85b553';
const API = 'https://bff-search-web.domclick.ru/api/offers/v1';
const TYPES = { office: 'office', retail: 'retail', freePurpose: 'free_purpose', warehouse: 'warehouse', industrial: 'manufacturing' };
const LABELS = { office: 'Офис', retail: 'Торговое помещение', free_purpose: 'Помещение свободного назначения', warehouse: 'Склад', manufacturing: 'Производство', catering: 'Общепит', hotel: 'Гостиница', commercial_land: 'Коммерческая земля' };
const LOCAL = [];
const fail = (message, url) => { throw new ScraperError('PARSE_FAILED', `domclick: ${message}`, { url }); };
const number = v => typeof v === 'number' && Number.isFinite(v) ? v : null;

// SSR is JSON with bare undefined literals. Replace only tokens outside JSON
// strings, then use the shared balanced JSON reader. No page code is executed.
function extractState(html) {
  const $ = cheerio.load(html);
  const script = $('script:not([src])').toArray().map(e => $(e).text()).find(s => /window\.__SSR_STATE__\s*=/.test(s));
  if (!script) return null;
  let quoted = false; let escaped = false; let safe = '';
  for (let i = 0; i < script.length; i++) {
    const ch = script[i];
    if (quoted) {
      safe += ch;
      if (escaped) escaped = false;
      else if (ch === '\\') escaped = true;
      else if (ch === '"') quoted = false;
    } else if (ch === '"') { quoted = true; safe += ch; }
    else if (script.slice(i, i + 9) === 'undefined' && !/[\w$]/.test(script[i - 1] || '') && !/[\w$]/.test(script[i + 9] || '')) { safe += 'null'; i += 8; }
    else safe += ch;
  }
  const match = /window\.__SSR_STATE__\s*=\s*/.exec(safe);
  return extractAssignedJson(safe.slice(match.index + match[0].length), '');
}

class DomclickParser extends SourceParser {
  constructor(config = {}) {
    super('domclick', config);
    this.nativeMultiType = true;
    this.splitTypesInReport = false;
    this.pageParam = 'offset'; this.offset = true;
  }

  reportPlan() {
    // Floor and districts are sent to the site: the server filters on the real
    // floor value (cards may display a basement as floor 1, so report still
    // checks the description), and district names resolve to aids through
    // lib/districts.js before the request.
    return { localFilters: [...LOCAL] };
  }

  normalizeData(items, sourceName = this.sourceName) {
    return super.normalizeData(items, sourceName).map((item, i) => ({ ...item,
      address: items[i].address ?? null, description: items[i].description ?? null }));
  }

  buildSearchUrl(input = {}) {
    const q = normalizeQuery(input);
    if (q.category !== 'commercial') return super.buildSearchUrl(q);
    const o = q.sourceOptions?.domclick || {};
    if (o.params != null && (typeof o.params !== 'object' || Array.isArray(o.params))) throw new TypeError('Native params must be an object');
    const url = o.url ? this.assertUrl(o.url) : new URL('/search', this.baseUrl);
    const params = url.searchParams;
    if (!o.url) {
      params.set('category', 'commercial'); params.set('deal_type', q.deal);
      const types = q.types || [q.type];
      for (const type of types) {
        if (type === 'commercial') continue;
        if (!TYPES[type]) this.unsupported(`type=${type} has no verified Domclick equivalent`);
        params.append('offer_type', TYPES[type]);
      }
      const address = o.address || o.params?.address;
      if (address) params.set('address', address);
      else if (/^(москва|moskva)$/i.test(q.city || q.citySlug || '')) params.set('address', MOSCOW);
      else this.unsupported('city requires a verified Domclick address GUID in sourceOptions.domclick.address');
    }
    // Names must first resolve to aids (buildSearchLinks/search/report do it);
    // a direct call without IDs is rejected rather than silently expanded.
    if ((q.district || q.districts?.length) && o.districtIds == null) throw new ScraperError('DISTRICT_RESOLUTION_REQUIRED', 'domclick: resolve district names with buildSearchLinks()/search() or provide sourceOptions.domclick.districtIds', { source: 'domclick' });
    for (const key of ['metro', 'sort', 'query']) if (q[key] != null) this.unsupported(`${key} has no verified mapping`);
    const price = (params.get('deal_type') || q.deal) === 'rent' ? 'rent_price' : 'sale_price';
    for (const [key, param] of Object.entries({ priceMin: `${price}__gte`, priceMax: `${price}__lte`, areaMin: 'area__gte', areaMax: 'area__lte', floorMin: 'floor__gte', floorMax: 'floor__lte' })) {
      if (q[key] != null) params.set(param, q[key]);
    }
    if (q.floorMode === 'first') { params.set('floor__gte', 1); params.set('floor__lte', 1); }
    if (q.floorMode === 'notBasement') params.set('floor__gte', Math.max(q.floorMin ?? 1, 1));
    if (q.owner === 'owner') params.set('is_owner', 1);
    if (o.districtIds != null) {
      if (!Array.isArray(o.districtIds) || !o.districtIds.length || o.districtIds.some(x => !/^\d+$/.test(String(x)))) throw new TypeError('districtIds must be nonempty numeric IDs');
      params.delete('aids'); for (const id of o.districtIds) params.append('aids', id);
    }
    for (const [key, value] of Object.entries(o.params || {})) {
      params.delete(key);
      if (value != null) for (const v of Array.isArray(value) ? value : [value]) {
        if (!['string', 'number', 'boolean'].includes(typeof v)) throw new TypeError(`Invalid native param: ${key}`);
        params.append(key, String(v));
      }
    }
    const size = o.pageSize ?? Number(params.get('limit') || 20);
    if (!Number.isSafeInteger(size) || size < 1 || size > 100) throw new TypeError('pageSize must be an integer from 1 to 100');
    if (o.pageParam && o.pageParam !== 'offset') this.unsupported('pagination uses offset, not page');
    if (!o.url || q.page > 1) params.set('offset', (q.page - 1) * size);
    params.set('limit', size);
    return this.assertUrl(url.toString()).toString();
  }

  normalizeOffer(offer, url) {
    if (!offer || typeof offer !== 'object' || offer.id == null || !offer.path || !offer.offerType || !['sale', 'rent'].includes(offer.dealType)) fail('invalid offer schema', url);
    let link;
    try { link = this.assertUrl(offer.path); } catch { fail('invalid offer path', url); }
    link.search = ''; link.hash = '';
    if (!/^\/card\//.test(link.pathname)) fail('invalid offer path', url);
    const info = offer.objectInfo || {};
    const description = typeof offer.description === 'string' ? offer.description : null;
    const negative = description?.match(/(?:на\s+|этаж\s*[:—-]\s*)([-−]\d+)\s*[-–]?(?:м\s+)?(?:этаж|$)/i);
    const inferred = inferFloor(description || '');
    let floor = negative ? -Math.abs(Number(negative[1].replace('−', '-'))) : number(info.floor);
    const basement = negative || inferred.floorType === 'basement';
    // Real BFF snippets lose the minus sign: floor=1 for a -1/basement
    // listing. The description is the only retained sign evidence.
    if (basement && floor > 0) floor = null;
    const type = Object.keys(TYPES).find(k => TYPES[k] === offer.offerType) || (LABELS[offer.offerType] ? 'otherCommercial' : null);
    const address = typeof offer.address?.displayName === 'string' ? offer.address.displayName : null;
    const parts = offer.seoInfo?.displayNameParts || [];
    const city = parts.find(p => !p.isBuilding && p.subdomain && !p.uri)?.title || null;
    const district = offer.address?.district?.name || null;
    const price = number(offer.price);
    const sellerType = offer.isOwner === true ? 'owner' : offer.seller?.agent?.isAgent === true || offer.seller?.agent?.isAgency === true ? 'agent' : null;
    return { id: String(offer.id), title: offer.title || [LABELS[offer.offerType] || offer.offerType, number(info.area) != null ? `${info.area} м²` : null].filter(Boolean).join(', '),
      url: link.toString(), price, priceText: price == null ? null : `${price.toLocaleString('ru-RU')} ₽${offer.dealType === 'rent' ? '/мес.' : ''}`,
      area: number(info.area), floor, floorType: basement || floor != null && floor <= 0 ? 'basement' : floor != null ? 'aboveGround' : null,
      propertyType: type, category: type ? 'commercial' : null, deal: offer.dealType, sellerType, city, district, address,
      description,
      images: (Array.isArray(offer.photos) ? offer.photos : []).map(p => p?.url).filter(p => typeof p === 'string').map(p => {
        try { const image = new URL(p, 'https://img.dmclk.ru/'); return /^https?:$/.test(image.protocol) ? image.toString() : null; } catch { return null; }
      }).filter(Boolean) };
  }

  parsePage(document, url, input = {}) {
    const q = normalizeQuery(input);
    let data = document; let state = null; let visible = ''; let empty = false;
    if (typeof data === 'string') {
      const trimmed = data.trim();
      if (trimmed.startsWith('{')) { try { data = JSON.parse(trimmed); } catch { fail('invalid JSON', url); } }
      else {
        const $ = cheerio.load(data);
        const body = $('body').clone(); body.find('script,style,noscript').remove(); visible = body.text();
        const emptyText = $('h1,h2,[data-e2e-id*="empty"],[data-testid="empty-results"]').text() + (visible.length < 1500 ? visible : '');
        empty = /ничего не найдено|объявлений не найдено|нет объявлений по вашему запросу/i.test(emptyText);
        if (/captcha|access denied|qrator|доступ ограничен|проверка безопасности|подтвердите.{0,40}человек|just a moment|forbidden/i.test($('title,h1').text() + ' ' + visible.slice(0,2500)) || $('form[action*="captcha"],#captcha,.SmartCaptcha,#challenge-running,script[src*="/__qrator/"]').length) throw new ScraperError('ACCESS_BLOCKED', 'domclick: access restriction or captcha', { url });
        const pre = $('pre').first().text().trim();
        if (pre.startsWith('{')) { try { data = JSON.parse(pre); } catch { fail('invalid browser JSON', url); } }
        else { state = extractState(data); data = null; }
      }
    }
    if ([401, 403, 429].includes(data?.status) || [401, 403, 429].includes(data?.statusCode) || data?.captcha) throw new ScraperError('ACCESS_BLOCKED', 'domclick: API access restriction', { url });
    let offers; let pagination;
    if (state) {
      const search = state.search;
      if (!search?.pages || search.status !== 'loaded') fail('SSR search is not loaded', url);
      // Hydrated pages can retain the original SSR after a client navigation.
      // Detect stale state instead of reporting the original search as current.
      const applied = search.lastSearchQueryParams || search.filters?.applied || {};
      const requested = new URL(url).searchParams;
      for (const key of ['category', 'deal_type', 'address', 'is_owner', 'sale_price__gte', 'sale_price__lte', 'rent_price__gte', 'rent_price__lte', 'area__gte', 'area__lte', 'floor__gte', 'floor__lte', 'offer_type', 'aids']) {
        const values = requested.getAll(key);
        if (!values.length) continue;
        const actual = Array.isArray(applied[key]) ? applied[key].map(String) : applied[key] == null ? [] : [String(applied[key])];
        if (values.length !== actual.length || values.some(v => !actual.includes(v))) fail(`SSR filter mismatch: ${key}`, url);
      }
      const offset = Number(requested.get('offset') || 0);
      if (number(search.pagination?.offset) !== offset) fail('stale SSR pagination', url);
      const page = search.pages[String(offset)];
      if (!page || !Array.isArray(page.ids) || !page.entities) fail('missing SSR page', url);
      offers = page.ids.map(id => page.entities[id]);
      pagination = { ...search.pagination, total: search.paginationTotal };
    } else if (data?.result && Array.isArray(data.result.items)) { offers = data.result.items; pagination = data.result.pagination; }
    else if (q.category !== 'commercial' && typeof document === 'string') return super.parsePage(document, url, q);
    else if (empty) return { results: [], hasNext: false, nextUrl: null, sourceTotal: 0 };
    else fail('missing offers or recognized SSR state', url);
    if (!pagination || !Number.isSafeInteger(pagination.total) || pagination.total < 0 || !Number.isSafeInteger(pagination.offset) || pagination.offset < 0 || !Number.isSafeInteger(pagination.limit) || pagination.limit < 1) fail('invalid pagination', url);
    if (pagination.offset !== Number(new URL(url).searchParams.get('offset') || 0)) fail('response offset does not match requested page', url);
    if (!offers.length && pagination.total > pagination.offset) fail('nonempty search has no items', url);
    const items = offers.map(o => this.normalizeOffer(o, url));
    if (q.category === 'commercial' && items.some(i => i.category !== 'commercial')) fail('commercial search returned a different category', url);
    const unique = [...new Map(items.map(i => [i.url, i])).values()];
    const hasNext = offers.length > 0 && pagination.offset + pagination.limit < pagination.total;
    const next = new URL(url);
    next.searchParams.set('offset', pagination.offset + pagination.limit); next.searchParams.set('limit', pagination.limit);
    return { results: this.normalizeData(unique), hasNext, nextUrl: hasNext ? next.toString() : null, sourceTotal: pagination.total };
  }

  async searchPage(input = {}, pageUrl) {
    const q = normalizeQuery(input);
    if (q.category !== 'commercial') return super.searchPage(q, pageUrl);
    const searchUrl = pageUrl ? this.assertUrl(pageUrl).toString() : this.buildSearchUrl(q);
    const native = new URL(searchUrl); let requestUrl = searchUrl;
    // A caller-supplied browser transport navigates the normal search page;
    // ordinary axios uses the public, unauthenticated BFF JSON endpoint.
    if (!this.config.transport && native.pathname !== '/api/offers/v1') {
      const api = new URL(API); api.search = native.search; requestUrl = api.toString();
    }
    const response = await this.fetch(requestUrl, { signal: q.signal, returnResponse: true, headers: { Accept: 'application/json,text/html' } });
    const final = this.assertUrl(response.url);
    const offset = Number(final.searchParams.get('offset') || native.searchParams.get('offset') || 0);
    const size = Number(final.searchParams.get('limit') || native.searchParams.get('limit') || 20);
    if (!Number.isSafeInteger(offset) || offset < 0 || !Number.isSafeInteger(size) || size < 1 || offset % size) fail('invalid effective page', final.toString());
    const parsed = this.parsePage(response.data, final.toString(), q);
    return { ...parsed, source: this.sourceName, page: offset / size + 1, url: final.toString() };
  }

  getCapabilities() {
    return { source: this.sourceName, nativeUrl: true, nativeParams: true, nativeMultiType: true, pagination: 'offset',
      unifiedFilters: ['city', 'category', 'types', 'deal', 'priceMin', 'priceMax', 'areaMin', 'areaMax', 'floorMin', 'floorMax', 'floorMode', 'owner'],
      localFilters: [...LOCAL], note: 'Public BFF JSON by default; custom transports may return search HTML or JSON. Automatic city mapping: Moscow only. District names and semantic floorMode are checked locally by report.' };
  }
}
DomclickParser.extractState = extractState;
module.exports = DomclickParser;
