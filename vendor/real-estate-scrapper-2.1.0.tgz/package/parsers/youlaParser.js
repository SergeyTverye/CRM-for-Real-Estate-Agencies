'use strict';
const SourceParser = require('../lib/sourceParser');
const { normalizeQuery, location } = require('../lib/query');
const { ScraperError } = require('../lib/errors');
const { randomBytes } = require('node:crypto');
const { TYPE_IDS, FEED_HASH, getState, normalizeDetail } = require('../lib/youla');
class YoulaParser extends SourceParser {
  constructor(config = {}) { super('youla', config); this.publicUid = randomBytes(7).toString('hex'); this.cityCache = new Map(); this.nativeMultiType = true; }
  reportPlan() { return { localFilters: ['districts', 'floorMode', 'floorMin', 'floorMax'] }; }
  buildSearchUrl(input = {}) {
    const q = normalizeQuery(input); const o = q.sourceOptions?.youla || {};
    if (q.category !== 'commercial' && !o.url?.includes('kommercheskaya-nedvijimost')) return super.buildSearchUrl(q);
    const slug = location(q, 'youla').slug;
    if (!slug && !o.url) throw new ScraperError('LOCATION_REQUIRED', 'Youla requires city/citySlug or native commercial URL');
    const url = o.url ? this.assertUrl(o.url) : new URL(`/${slug}/nedvijimost/kommercheskaya-nedvijimost`, this.baseUrl);
    if (!url.pathname.includes('/kommercheskaya-nedvijimost')) this.unsupported('commercial search needs commercial category URL');
    if ((q.floorMode && q.floorMode !== 'any') || q.floorMin != null || q.floorMax != null || q.district || q.districts?.length) this.unsupported('floor/district require verified report filtering');
    if (q.deal === 'daily') this.unsupported('commercial daily rent');
    if (!o.url || q.types) {
      const types = q.types || [q.type];
      for (const key of [...url.searchParams.keys()]) if (key.startsWith('attributes[kommer_realty_tip_stroeniya]')) url.searchParams.delete(key);
      types.filter(t => t !== 'commercial').forEach((type, i) => {
        if (!TYPE_IDS[type]) this.unsupported(`type=${type}`);
        url.searchParams.set(`attributes[kommer_realty_tip_stroeniya][${i}]`, TYPE_IDS[type]);
      });
    }
    if (!o.url) url.searchParams.set('attributes[tip_sdelki][0]', q.deal === 'rent' ? '10806' : '10807');
    if (q.owner === 'owner') url.searchParams.set('attributes[sobstvennik_ili_agent][0]', '10705');
    const ranges = { price: ['price', 100], area: ['realty_obshaya_ploshad', 100] };
    for (const [prefix, [slug, factor]] of Object.entries(ranges)) for (const [suffix, bound] of [['Min', 'from'], ['Max', 'to']]) {
      if (q[prefix + suffix] != null) url.searchParams.set(`attributes[${slug}][${bound}]`, Math.round(q[prefix + suffix] * factor));
    }
    if (q.query) url.searchParams.set('q', q.query);
    for (const [k, v] of Object.entries(o.params || {})) { url.searchParams.delete(k); if (v != null) for (const part of Array.isArray(v) ? v : [v]) url.searchParams.append(k, String(part)); }
    return url.toString();
  }
  async cityFor(url, q) {
    const slug = new URL(url).pathname.split('/')[1];
    const supplied = q.sourceOptions?.youla?.cityId;
    if (supplied) return { id: supplied, name: q.city || null };
    if (this.cityCache.has(slug)) return this.cityCache.get(slug);
    const state = getState(await this.fetch(url, { signal: q.signal }));
    const candidates = state?.entities?.cities || state?.data?.cities || [];
    const values = Array.isArray(candidates) ? candidates : Object.values(candidates);
    const city = values.find(c => c.slug === slug);
    if (!city?.id) throw new ScraperError('LOCATION_NOT_FOUND', `Youla city '${slug}' could not be resolved`);
    this.cityCache.set(slug, { id: city.id, name: city.name }); return this.cityCache.get(slug);
  }
  async searchPage(input = {}, pageUrl) {
    const q = normalizeQuery(input); const url = pageUrl ? this.assertUrl(pageUrl).toString() : this.buildSearchUrl(q);
    const u = new URL(url); const city = await this.cityFor(url, q);
    const attributes = new Map();
    for (const [key, value] of u.searchParams) {
      const match = key.match(/^attributes\[([^\]]+)\]\[([^\]]+)\]$/); if (!match) continue;
      const field = attributes.get(match[1]) || { slug: match[1], value: [], from: null, to: null };
      if (['from', 'to'].includes(match[2])) { field[match[2]] = Number(value); if (!field.value?.length) field.value = null; }
      else { field.value ||= []; field.value.push(value); }
      attributes.set(match[1], field);
    }
    attributes.set('categories', { slug: 'categories', value: ['kommercheskaya-nedvijimost'], from: null, to: null });
    const cursor = u.searchParams.get('cursor') || '';
    if (q.page > 1 && !cursor) throw new ScraperError('CURSOR_REQUIRED', 'Youla pages are sequential: use searchPages/maxPages rather than a random page number');
    const payload = { operationName: 'catalogProductsBoard', variables: { sort: 'DEFAULT', attributes: [...attributes.values()], datePublished: null,
      location: { latitude: null, longitude: null, city: city.id, distanceMax: null }, search: u.searchParams.get('q') || '', cursor },
      extensions: { persistedQuery: { version: 1, sha256Hash: FEED_HASH } } };
    const data = await this.fetch('https://api-gw.youla.ru/graphql', { method: 'POST', data: payload, signal: q.signal,
      headers: { appId: 'web/3', 'x-app-id': 'web/3', uid: this.publicUid, 'x-uid': this.publicUid, 'x-offset-utc': '3', authorization: '', Referer: 'https://youla.ru/', 'Content-Type': 'application/json', Accept: '*/*' } });
    if (data?.errors?.length || !Array.isArray(data?.data?.feed?.items) || typeof data.data.feed.pageInfo?.hasNextPage !== 'boolean') throw new ScraperError('API_RESPONSE_FAILED', 'Youla feed schema changed or GraphQL returned errors');
    const feed = data.data.feed;
    const results = feed.items.filter(i => i.product).map(({ product: p }) => ({ id: p.id, title: p.name,
      price: typeof p.price?.realPrice?.price === 'number' ? p.price.realPrice.price / 100 : null, priceText: p.price?.realPriceText,
      area: Number(p.name.match(/(\d+(?:[.,]\d+)?)\s*м²/)?.[1]?.replace(',', '.')) || null,
      category: p.subcategoryId === 2013 ? 'commercial' : null, city: p.location?.cityName, cityId: p.location?.city,
      address: p.location?.addressText || '', url: this.assertUrl(p.url).toString(), images: p.images?.map(i => i.url) || [] }));
    const next = feed.pageInfo?.cursor;
    if (feed.pageInfo.hasNextPage && (!next || next === cursor)) throw new ScraperError('PAGINATION_FAILED', 'Youla declared a next page without a new cursor');
    const hasNext = Boolean(feed.pageInfo?.hasNextPage && next && next !== cursor);
    const nextUrl = new URL(url); nextUrl.searchParams.set('cursor', next || '');
    return { source: 'youla', page: q.page, url, results: this.normalizeData(results), hasNext, nextUrl: hasNext ? nextUrl.toString() : null };
  }
  async fetchDetails(item, q = {}) {
    const url = this.assertUrl(item.url).toString(); const state = getState(await this.fetch(url, { signal: q.signal }));
    const values = state?.entities?.products || {};
    const product = values[item.id] || Object.values(values).find(p => p.id === item.id);
    if (!product || product.isDeleted || product.isArchived || product.isSold) throw new ScraperError('LISTING_UNAVAILABLE', 'Youla listing is no longer available', { url });
    const cities = state.entities.cities || [];
    const city = (Array.isArray(cities) ? cities : Object.values(cities)).find(c => c.id === product.location?.city);
    return this.normalizeData([{ ...item, ...normalizeDetail(product, city) }])[0];
  }
  getCapabilities() {
    return { ...super.getCapabilities(), unifiedFilters: ['types', 'owner', 'priceMin', 'priceMax', 'areaMin', 'areaMax', 'query'],
      pagination: 'cursor', note: 'Commercial GraphQL API; floors and non-native districts require report verification. Arbitrary page numbers are not supported.' };
  }
}
module.exports = YoulaParser;
