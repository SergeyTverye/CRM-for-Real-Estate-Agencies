'use strict';
const axios = require('axios');
const cheerio = require('cheerio');
const { HttpsProxyAgent } = require('https-proxy-agent');
const { normalizeQuery } = require('../lib/query');
const { ScraperError } = require('../lib/errors');

class BaseParser {
  constructor(config = {}) {
    this.config = { delay: 1000, maxRetries: 2, timeout: 30000, ...config };
    for (const k of ['delay', 'maxRetries', 'timeout']) if (!Number.isFinite(this.config[k]) || this.config[k] < 0) throw new TypeError(`Invalid ${k}`);
    if (!Number.isInteger(this.config.maxRetries)) throw new TypeError('maxRetries must be an integer');
  }
  async delay(ms, signal) {
    if (signal?.aborted) throw new ScraperError('ABORTED', 'Search aborted');
    if (!ms) return;
    await new Promise((resolve, reject) => {
      const done = () => { signal?.removeEventListener('abort', abort); resolve(); };
      const timer = setTimeout(done, ms);
      const abort = () => { clearTimeout(timer); signal?.removeEventListener('abort', abort); reject(new ScraperError('ABORTED', 'Search aborted')); };
      signal?.addEventListener('abort', abort, { once: true });
    });
  }
  getHeaders() {
    return { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/131.0.0.0 Safari/537.36',
      Accept: 'text/html,application/xhtml+xml', 'Accept-Language': 'ru-RU,ru;q=0.9', ...this.config.headers };
  }
  // Overridden by parsers whose site answers an empty search with an HTTP error.
  isEmptyResultResponse() { return false; }
  async fetch(url, options = {}) {
    const request = { url, method: 'GET', timeout: this.config.timeout, ...options,
      headers: { ...this.getHeaders(), ...options.headers }, maxRedirects: 5 };
    delete request.returnResponse;
    if (typeof this.config.proxy === 'string') {
      request.httpsAgent = new HttpsProxyAgent(this.config.proxy); request.proxy = false;
    } else if (this.config.proxy) request.proxy = this.config.proxy;
    for (let attempt = 0; attempt <= this.config.maxRetries; attempt++) {
      try {
        if (options.signal?.aborted) throw new ScraperError('ABORTED', 'Search aborted');
        const response = await (this.config.transport || axios)(request);
        const data = response && typeof response === 'object' && 'data' in response ? response.data : response;
        // Some sites answer an empty search with an error status; parsers may
        // accept such a page only when it carries an explicit empty marker.
        if (response?.status >= 400 && !this.isEmptyResultResponse(response.status, data)) { const e = new Error(`HTTP ${response.status}`); e.response = response; throw e; }
        if (options.returnResponse) return { data, url: response?.url || response?.request?.res?.responseUrl || url };
        return data;
      } catch (e) {
        if (e.response && this.isEmptyResultResponse(e.response.status, e.response.data)) {
          const data = e.response.data;
          return options.returnResponse ? { data, url: e.response.request?.res?.responseUrl || url } : data;
        }
        if (options.signal?.aborted || e.code === 'ERR_CANCELED' || e.code === 'ABORTED') throw new ScraperError('ABORTED', 'Search aborted', { url });
        const status = e.response?.status;
        if ((status && status !== 429 && status < 500) || attempt === this.config.maxRetries) throw new ScraperError(
          [401, 403, 429].includes(status) ? 'ACCESS_BLOCKED' : 'FETCH_FAILED', e.message,
          { status, url, source: this.sourceName, cause: e });
        const retryAfter = Number(e.response?.headers?.['retry-after']);
        await this.delay(Number.isFinite(retryAfter) ? Math.min(retryAfter * 1000, 60000) : this.config.delay * (attempt + 1), options.signal);
      }
    }
  }
  parsePrice(text) {
    if (typeof text === 'number') return Number.isFinite(text) ? text : null;
    if (!text) return null;
    const match = String(text).replace(/[\s\u00a0\u202f]/g, '').match(/(\d+(?:[.,]\d+)?)(млрд|млн|тыс)?/i);
    return match ? Number(match[1].replace(',', '.')) * ({ 'млрд': 1e9, 'млн': 1e6, 'тыс': 1e3 }[match[2]?.toLowerCase()] || 1) : null;
  }
  assertUrl(value) {
    let u;
    try { u = new URL(value, this.baseUrl); } catch { throw new ScraperError('INVALID_URL', 'Invalid source URL'); }
    const domain = new URL(this.baseUrl).hostname.replace(/^www\./, '');
    if (u.protocol !== 'https:' || u.username || u.password || !(u.hostname === domain || u.hostname.endsWith('.' + domain))) throw new ScraperError('INVALID_URL', `URL must belong to ${domain}`);
    return u;
  }
  normalizeData(items, sourceName = this.sourceName) {
    return items.map(item => ({ ...item, source: sourceName,
      title: item.title ?? '', price: item.price ?? null, address: item.address ?? '',
      rooms: item.rooms ?? null, area: item.area ?? null, floor: item.floor ?? null,
      url: item.url ?? '', images: item.images ?? [], description: item.description ?? '',
      phone: item.phone ?? null, city: item.city ?? null, district: item.district ?? null,
      timestamp: new Date().toISOString() }));
  }
  parsePage(html, url, query) {
    if (typeof html !== 'string') throw new ScraperError('INVALID_RESPONSE', 'Expected HTML; supply a transport returning rendered HTML');
    const $ = cheerio.load(html);
    if (/captcha|доступ ограничен|проверка безопасности|подтвердите.{0,30}человек|just a moment|access denied/i.test($('title').text() + ' ' + $('h1').text()) || $('form[action*="captcha"], #captcha, .SmartCaptcha, #challenge-running').length) {
      throw new ScraperError('ACCESS_BLOCKED', 'Source returned a captcha or access restriction', { url });
    }
    const results = []; const seen = new Set();
    const pick = (card, selectors) => {
      for (const selector of selectors.split(',')) { const el = card.find(selector.trim()).first(); if (el.length) return el; }
      return card.find('__missing_element__');
    };
    const push = item => {
      if (!item.url || !item.title) return;
      let u; try { u = this.assertUrl(item.url); } catch { return; }
      u.hash = ''; item.url = u.toString();
      if (seen.has(item.url)) return; seen.add(item.url); results.push(item);
    };
    $(this.selectors.card).each((_, el) => {
      const card = $(el);
      const link = card.is('a') ? card : pick(card, this.selectors.link);
      const href = link.attr('href'); if (!href) return;
      const title = pick(card, this.selectors.title).text().trim() || link.attr('title') || link.text().trim();
      const priceEl = pick(card, this.selectors.price);
      const priceText = priceEl.attr('content') || priceEl.text().trim();
      const text = title + ' ' + card.text();
      const area = text.match(/(\d+(?:[.,]\d+)?)\s*(?:м²|м2|кв\.?\s*м)/i);
      const rooms = text.match(/(\d+)\s*[-–]?\s*(?:комн|к\b)/i);
      const floor = text.match(/(\d+)\s*\/\s*\d+\s*эт/i) || text.match(/(\d+)\s*(?:этаж\s*)?(?:из\s*\d+\s*)?этаж/i);
      const address = pick(card, this.selectors.address).text().trim().replace(/^[,\s]+/, '');
      const cityText = card.find('[address-city]').first().text();
      const district = cityText.split(',').map(part => part.trim())
        .map(part => part.match(/^(?:район|р-н)\s+(.+)$/i)?.[1] || part.match(/^(.+?)\s+район$/i)?.[1])
        .find(Boolean) || null;
      const wordRooms = { 'однокомнат': 1, 'двухкомнат': 2, 'трехкомнат': 3, 'трёхкомнат': 3, 'четырехкомнат': 4, 'четырёхкомнат': 4, 'пятикомнат': 5 };
      const wordRoom = Object.keys(wordRooms).find(word => title.toLowerCase().includes(word));
      // Keep the sign: OnRealt shows a socle/basement as "-1 / 6".
      const floorInfo = card.find('.info-container').filter((_, el) => /Этаж:/.test($(el).text())).find('.value').text().match(/[-−–]?\s*\d+/);
      const images = card.find('img').map((i, img) => $(img).attr('data-src') || $(img).attr('src')).get().filter(Boolean)
        .map(src => { try { return new URL(src, url).toString(); } catch { return null; } }).filter(src => /^https?:/.test(src || ''));
      let itemUrl; try { itemUrl = new URL(href, url).toString(); } catch { return; }
      push({ id: card.attr('data-id') || new URL(itemUrl).pathname.match(/\/(\d+)\/?$/)?.[1] || null, title, price: this.parsePrice(priceText), priceText, address,
        rooms: /студи/i.test(title) ? 0 : rooms ? Number(rooms[1]) : wordRoom ? wordRooms[wordRoom] : null,
        area: area ? Number(area[1].replace(',', '.')) : null,
        floor: floorInfo ? Number(floorInfo[0].replace(/[−–]/, '-').replace(/\s+/g, '')) : floor ? Number(floor[1]) : null,
        floorType: floorInfo ? (Number(floorInfo[0].replace(/[−–]/, '-').replace(/\s+/g, '')) >= 1 ? 'aboveGround' : 'basement') : undefined,
        url: itemUrl, images: [...new Set(images)],
        city: card.find('[address-city]').first().text().split(',')[0].trim() || null,
        district, propertyType: require('../lib/verification').inferPropertyType(title),
        deal: /\/(?:kypit-|sale\/)/.test(itemUrl) ? 'sale' : /\/(?:snyat-|arenda-|rent\/)/.test(itemUrl) ? 'rent' : null,
        description: card.find('[itemprop="description"], [class*="description"], [data-name="Description"], .descr, .wRlHb').first().text().trim() });
    });
    $('script[type="application/ld+json"]').each((_, el) => {
      let data; try { data = JSON.parse($(el).text()); } catch { return; }
      const walk = node => {
        if (Array.isArray(node)) return node.forEach(walk);
        if (!node || typeof node !== 'object') return;
        const offer = Array.isArray(node.offers) ? node.offers[0] : node.offers;
        const summary = ['CollectionPage', 'SearchResultsPage', 'WebPage', 'Organization', 'ItemList'].includes(node['@type']) || offer?.['@type'] === 'AggregateOffer';
        let detail = false;
        try {
          const candidate = new URL(node.url || offer?.url, url);
          detail = candidate.pathname !== new URL(url).pathname &&
            (this.sourceName !== 'yandex' || /^\/offer\/\d+\/?$/.test(candidate.pathname));
        } catch { /* Not a listing URL. */ }
        if (!summary && detail && node.name && (node.url || offer?.url) && offer) push({ title: node.name, url: node.url || offer.url,
          price: this.parsePrice(offer.price), address: typeof node.address === 'string' ? node.address : node.address?.streetAddress,
          area: Number(node.floorSize?.value) || null, rooms: node.numberOfRooms ?? null, description: node.description || '',
          images: (Array.isArray(node.image) ? node.image : [node.image]).filter(x => typeof x === 'string') });
        for (const v of Object.values(node)) if (v && typeof v === 'object') walk(v);
      }; walk(data);
    });
    const next = $('a[rel="next"], a[data-name="PaginationButtonNext"], a[aria-label*="Следующая"], a[aria-label*="следующая"], a[title*="Следующая"]').filter((_, el) => !$(el).is('[aria-disabled="true"], [disabled]')).first().attr('href');
    let nextUrl = next ? this.assertUrl(new URL(next, url).toString()).toString() : null;
    if (!nextUrl) $('a[href]').each((_, el) => {
      if (nextUrl) return;
      let u; try { u = this.assertUrl(new URL($(el).attr('href'), url).toString()); } catch { return; }
      const current = new URL(url);
      const o = query.sourceOptions?.[this.sourceName] || {};
      const param = o.pageParam || this.pageParam;
      const currentPage = Number(current.searchParams.get(param) ?? (this.offset ? 0 : query.page));
      const step = this.offset && !o.pageParam ? (o.pageSize ?? 20) : 1;
      if (u.pathname === current.pathname && Number(u.searchParams.get(param)) === currentPage + step) nextUrl = u.toString();
    });
    const visibleBody = $('body').clone(); visibleBody.find('script,style,noscript').remove();
    const visibleText = visibleBody.text().trim();
    const emptyText = $('h1,h2,[data-name="EmptyResult"],[data-testid="empty-results"],[data-test="EmptySearch"],[class*="EmptySearch"],.empty-result').text()
      + (visibleText.length < 1000 ? visibleText : '');
    const empty = /ничего не найдено|объявлений не найдено|нет объявлений|найдено\s+0\b|(?<!\d)0\s+объявлений|no results/i.test(emptyText);
    if (!results.length && !empty) throw new ScraperError('PARSE_FAILED', 'No listing cards or explicit empty-search marker found; page may require JavaScript or selectors have changed', { url });
    return { results: this.normalizeData(results), nextUrl, hasNext: Boolean(nextUrl) };
  }
  async searchPage(input = {}, pageUrl) {
    const q = normalizeQuery(input); const url = pageUrl ? this.assertUrl(pageUrl).toString() : this.buildSearchUrl(q);
    const document = await this.fetch(url, { signal: q.signal, returnResponse: true });
    const finalUrl = this.assertUrl(document.url).toString();
    const o = q.sourceOptions?.[this.sourceName] || {};
    const rawPage = new URL(finalUrl).searchParams.get(o.pageParam || this.pageParam);
    let effectivePage = q.page;
    if (rawPage != null && Number.isSafeInteger(Number(rawPage))) {
      const candidate = this.offset && !o.pageParam ? Number(rawPage) / (o.pageSize ?? 20) + 1 : Number(rawPage);
      if (Number.isSafeInteger(candidate) && candidate >= 1) effectivePage = candidate;
    }
    return { ...this.parsePage(document.data, finalUrl, { ...q, page: effectivePage }), source: this.sourceName, page: effectivePage, url: finalUrl };
  }
  async extractData(filters = {}) {
    const q = normalizeQuery(filters); const results = []; const seen = new Set(); let nextUrl;
    for (let i = 0; i < q.maxPages; i++) {
      if (i) await this.delay(this.config.delay, q.signal);
      const sourceOptions = { ...q.sourceOptions, [this.sourceName]: { ...q.sourceOptions?.[this.sourceName], ...(nextUrl ? { url: nextUrl } : {}) } };
      const page = await this.searchPage({ ...q, page: q.page + i, sourceOptions }, nextUrl);
      let added = 0;
      for (const item of page.results) if (!seen.has(item.url)) { seen.add(item.url); results.push(item); added++; }
      if ((q.limit && results.length >= q.limit) || !added || !page.hasNext) break;
      nextUrl = page.nextUrl;
    }
    return q.limit ? results.slice(0, q.limit) : results;
  }
  saveToJson(data, filename) {
    const fs = require('fs'); const path = require('path');
    const root = path.resolve(process.cwd(), 'data'); const target = path.resolve(root, filename);
    if (!target.startsWith(root + path.sep)) throw new TypeError('filename must be inside data/');
    fs.mkdirSync(path.dirname(target), { recursive: true }); fs.writeFileSync(target, JSON.stringify(data, null, 2), 'utf8'); return target;
  }
}
module.exports = BaseParser;
