'use strict';
const SourceParser = require('../lib/sourceParser');
const cheerio = require('cheerio');
const { normalizeQuery, location } = require('../lib/query');
const { ScraperError } = require('../lib/errors');

const name = value => String(value || '').toLocaleLowerCase('ru-RU').replace(/ё/g, 'е').replace(/^(?:район|р-н)\s+|\s+район$/g, '').trim();
const emptyBox = $ => $('.box-view-ad').toArray().some(e => /^Объявлений не найдено\.$/u.test($(e).text().trim()));
// The modal exists on ordinary search pages too. State 2 is explicitly hidden
// by the site's stylesheet; states 0/1 mean the challenge is active.
const blocked = $ => $('[robot-action-status="0"], [robot-action-status="1"]').length > 0;

class OnRealtParser extends SourceParser {
  constructor(config = {}) { super('onrealt', config); }
  // OnRealt returns HTTP 404 for a valid search without results and for
  // commercial categories that currently have no listings in a city.
  isEmptyResultResponse(status, data) {
    if (status !== 404 || typeof data !== 'string') return false;
    const $ = cheerio.load(data);
    // Admit a challenge page to parsePage so it receives ACCESS_BLOCKED,
    // rather than being mistaken for either a missing URL or an empty search.
    return blocked($) || emptyBox($);
  }

  parsePage(html, url, query = {}) {
    if (typeof html !== 'string') return super.parsePage(html, url, query);
    const $ = cheerio.load(html);
    if (blocked($)) throw new ScraperError('ACCESS_BLOCKED', 'OnRealt: active robot verification', { source: this.sourceName, url });
    // Generic fallback selectors include navigation li.item, so only real
    // OnRealt listing containers can contradict the explicit empty marker.
    if (emptyBox($) && !$('.ad-item-container, .box-view-ad [url-item]').length) return { results: [], hasNext: false, nextUrl: null, sourceTotal: 0 };
    return super.parsePage(html, url, query);
  }

  reportPlan(q) {
    return { localFilters: q.type !== 'office' ? ['floorMode', 'floorMin', 'floorMax'] : [] };
  }

  buildSearchUrl(input = {}) {
    const q = normalizeQuery(input); const o = q.sourceOptions?.onrealt || {};
    const ids = o.districtIds;
    if (ids != null && (!Array.isArray(ids) || !ids.length || ids.some(id => !/^\d+$/.test(String(id))))) throw new TypeError('districtIds must be nonempty numeric IDs');
    if ((q.district || q.districts?.length) && !ids?.length) throw new ScraperError('DISTRICT_RESOLUTION_REQUIRED', 'OnRealt: resolve district names with buildSearchLinks() or supply districtIds', { source: this.sourceName });
    // The shared mapper does not yet know OnRealt's location JSON. Delegate
    // the other filters unchanged and add the verified geography ourselves.
    const native = { ...o }; delete native.districtIds;
    const clean = { ...q, sourceOptions: { ...q.sourceOptions, onrealt: native } };
    delete clean.district; delete clean.districts;
    const url = new URL(super.buildSearchUrl(clean));
    if (ids?.length) {
      let geo = {};
      if (url.searchParams.has('location')) {
        try { geo = JSON.parse(url.searchParams.get('location')); } catch { throw new TypeError('Native location must be JSON'); }
        if (!geo || typeof geo !== 'object' || Array.isArray(geo)) throw new TypeError('Native location must be a JSON object');
      }
      url.searchParams.set('location', JSON.stringify({ ...geo, 4: [...new Set(ids.map(String))] }));
    }
    return url.toString();
  }

  async getDistricts(input = {}) {
    const q = normalizeQuery(input);
    const names = q.districts || (q.district ? [q.district] : []);
    // This public endpoint is an autocomplete, capped at 20 suggestions.
    // Look up the requested names instead of pretending it is a full catalog.
    if (!names.length) this.unsupported('district autocomplete requires district/districts names; a complete district catalog is not published');
    const city = q.city || q.citySlug || location(q, 'onrealt').slug;
    if (!city) throw new ScraperError('LOCATION_REQUIRED', 'OnRealt: city is required for district lookup');
    const read = async url => {
      let data = await this.fetch(url, { signal: q.signal });
      if (typeof data === 'string') {
        if (blocked(cheerio.load(data))) throw new ScraperError('ACCESS_BLOCKED', 'OnRealt: district lookup requires robot verification', { url });
        try { data = JSON.parse(data); } catch { throw new ScraperError('DISTRICT_LOOKUP_FAILED', 'OnRealt: geographic API did not return JSON', { url }); }
      }
      return data;
    };
    this.regionCache ||= new Map(); this.districtCache ||= new Map();
    const slug = location(q, 'onrealt').slug;
    const cityKey = slug || name(city);
    let region = this.regionCache.get(cityKey);
    if (!region) {
      const url = new URL('/core/api-region/', this.baseUrl); url.searchParams.set('input', city);
      const candidates = await read(url.toString());
      if (!Array.isArray(candidates)) throw new ScraperError('DISTRICT_LOOKUP_FAILED', 'OnRealt: unexpected region schema');
      const matches = candidates.filter(r => slug ? r.code === slug : name(r.name) === name(city));
      if (matches.length !== 1 || !/^\d+$/.test(String(matches[0].id))) throw new ScraperError('DISTRICT_LOOKUP_FAILED', 'OnRealt: city is missing or ambiguous in region API');
      region = matches[0]; this.regionCache.set(cityKey, region);
    }
    const result = new Map();
    for (const requested of names) {
      const key = cityKey + ':' + name(requested);
      let districts = this.districtCache.get(key);
      if (!districts) {
        const selected = Object.fromEntries(Array.from({ length: 10 }, (_, i) => [i, ['']]));
        if (region['in-location'] === '0') selected[2] = [String(region.id)];
        const url = new URL('/core/api-search-location/', this.baseUrl);
        const enter = requested.replace(/^(?:район|р-н)\s+|\s+район$/gi, '').trim();
        url.searchParams.set('json_data', JSON.stringify({ type_region: region['in-location'] === '1' ? '2' : '1', action_region: String(region.region || region.id), length: enter.length, enter }));
        url.searchParams.set('json_select_loc', JSON.stringify(selected));
        const data = await read(url.toString());
        if (!data?.location || typeof data.location !== 'object' || Array.isArray(data.location)) throw new ScraperError('DISTRICT_LOOKUP_FAILED', 'OnRealt: unexpected district schema');
        const group = Object.values(data.location).find(g => String(g?.id) === '4');
        if (!group || (group.area != null && !Array.isArray(group.area))) throw new ScraperError('DISTRICT_LOOKUP_FAILED', 'OnRealt: missing district group');
        const area = group.area || [];
        if (area.some(d => !/^\d+$/.test(String(d.id)) || typeof d.name !== 'string' || !d.name.trim())) throw new ScraperError('DISTRICT_LOOKUP_FAILED', 'OnRealt: invalid district record');
        districts = area.filter(d => name(d.name) === name(requested) && (!d.parent_name || name(d.parent_name) === name(region.name)))
          .map(d => ({ id: String(d.id), name: d.name.replace(/^(?:район|р-н)\s+|\s+район$/gi, '').trim() }));
        this.districtCache.set(key, districts);
      }
      for (const d of districts) result.set(d.id, { ...d });
    }
    return [...result.values()];
  }

  getCapabilities() {
    const caps = super.getCapabilities();
    return { ...caps, unifiedFilters: [...new Set([...caps.unifiedFilters, 'districts'])],
      note: 'District names resolve through public geographic autocomplete; IDs use location={"4":[...]}. Office floors are native; other commercial floor constraints remain local in report.' };
  }
}
module.exports = OnRealtParser;
