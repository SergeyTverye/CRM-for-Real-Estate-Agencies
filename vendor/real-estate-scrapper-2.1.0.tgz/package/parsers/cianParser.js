'use strict';
const SourceParser = require('../lib/sourceParser');
const cheerio = require('cheerio');
const { extractAssignedJson } = require('../lib/embeddedState');
const { ScraperError } = require('../lib/errors');
class CianParser extends SourceParser {
  constructor(config = {}) { super('cian', config); }
  parsePage(html, url, query) {
    if (typeof html !== 'string') return super.parsePage(html, url, query);
    const $ = cheerio.load(html); let state;
    for (const script of $('script:not([src])').map((_, el) => $(el).text()).get()) {
      if (!script.includes("['legacy-commercial-serp-frontend']")) continue;
      const entries = extractAssignedJson(script, '.concat(');
      const candidate = Array.isArray(entries) ? entries.find(e => e.key === 'initialState')?.value : null;
      if (Array.isArray(candidate?.results?.offers)) { state = candidate; break; }
    }
    if (!state) return super.parsePage(html, url, query);
    const data = state.results;
    if (!data.offers.length && data.totalOffers !== 0) throw new ScraperError('PARSE_FAILED', 'Cian SSR offers are missing although totalOffers is nonzero', { url });
    const typeMap = { office: 'office', freeAppointment: 'freePurpose', shoppingArea: 'retail', floorSpace: 'retail',
      warehouse: 'warehouse', industry: 'industrial', production: 'industrial', building: 'building' };
    const results = data.offers.flatMap(o => {
      if (!o || !/^\d+$/.test(String(o.cianId || o.id || '')) || typeof (o.fullUrl || o.url) !== 'string') throw new ScraperError('PARSE_FAILED', 'Cian SSR listing identifier or URL is missing', { url });
      const link = this.assertUrl(o.fullUrl || o.url); link.search = ''; link.hash = '';
      const addresses = o.geo?.address || [];
      const floor = o.floorNumber == null ? null : Number(o.floorNumber);
      const propertyType = typeMap[o.officeType] || null;
      const label = { office: 'Офис', retail: 'Торговое помещение', freePurpose: 'Помещение свободного назначения', warehouse: 'Склад', industrial: 'Производственное помещение', building: 'Здание' }[propertyType] || 'Помещение';
      const listing = { id: String(o.cianId || o.id), url: link.toString(),
        title: `${label}, ${o.totalArea ?? '?'} м²${Number.isFinite(floor) ? ` · ${floor} этаж` : ''}`,
        price: o.bargainTerms?.priceRur ?? o.bargainTerms?.price ?? null,
        priceText: o.formattedFullPrice || o.formattedShortPrice || '',
        priceUnit: o.bargainTerms?.priceType || null,
        area: o.totalArea == null ? null : Number(o.totalArea),
        floor: Number.isFinite(floor) ? floor : null,
        floorType: floor == null || !Number.isFinite(floor) ? null : floor >= 1 ? 'aboveGround' : 'basement',
        propertyType, category: 'commercial', deal: o.dealType,
        sellerType: o.isByCommercialOwner === true ? 'owner' : o.isByCommercialOwner === false ? 'agent' : null,
        city: addresses.find(a => a.type === 'location')?.name || null,
        district: o.geo?.districts?.find(d => d.type === 'raion')?.name || null,
        districtIds: o.geo?.districts?.map(d => d.id) || [],
        address: addresses.filter(a => a.isFormingAddress || ['raion', 'okrug'].includes(a.type)).map(a => a.fullName || a.name).join(', '),
        description: o.description || '', images: o.photos?.map(p => p.fullUrl).filter(Boolean) || [],
        latitude: o.geo?.coordinates?.lat ?? null, longitude: o.geo?.coordinates?.lng ?? null };
      // A grouped card (several units in one building) carries the price and
      // area of one unit only; expand it so each unit is verified separately.
      const parts = Array.isArray(o.areaParts) ? o.areaParts.filter(p => p && Number.isFinite(Number(p.area))) : [];
      if (parts.length < 2) return [listing];
      return parts.map((part, i) => {
        const from = Number(part.floorFrom); const to = Number(part.floorTo);
        // A unit listed over a floor range is placed on its lowest floor at
        // best; that is enough to exclude it from a first-floor search.
        const partFloor = Number.isFinite(from) && (!Number.isFinite(to) || to === from || from > 1) ? from : null;
        const partFloorType = Number.isFinite(from) ? (from >= 1 ? 'aboveGround' : Number.isFinite(to) && to >= 1 ? null : 'basement') : null;
        return { ...listing, id: `${listing.id}-${i + 1}`, parentId: listing.id, url: `${listing.url}#part-${i + 1}`,
          title: `${label}, ${part.area} м²${partFloor != null ? ` · ${partFloor} этаж` : ''} (площадь ${i + 1} из ${parts.length})`,
          price: part.price ?? (part.pricePerMeterRur ? Math.round(part.pricePerMeterRur * part.area) : null),
          priceText: '', area: Number(part.area), floor: partFloor, floorType: partFloorType,
          floorRange: Number.isFinite(from) ? [from, Number.isFinite(to) ? to : from] : null };
      });
    });
    const currentPage = Number(new URL(url).searchParams.get('p')) || query.page;
    let next = data.paginationUrls?.find(link => { try { return Number(new URL(link, url).searchParams.get('p')) === currentPage + 1; } catch { return false; } });
    // Cian lists only nearby pages; derive the next page from the total count.
    if (!next && data.offers.length && Number.isFinite(data.totalOffers) && currentPage * data.offers.length < data.totalOffers) {
      const derived = new URL(url); derived.searchParams.set('p', currentPage + 1); next = derived.toString();
    }
    return { results: this.normalizeData(results), sourceTotal: data.totalOffers,
      hasNext: Boolean(next), nextUrl: next ? this.assertUrl(new URL(next, url).toString()).toString() : null };
  }
}
module.exports = CianParser;
