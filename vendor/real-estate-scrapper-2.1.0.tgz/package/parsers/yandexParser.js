'use strict';
const SourceParser = require('../lib/sourceParser');
class YandexParser extends SourceParser {
  constructor(config = {}) { super('yandex', config); }
}
module.exports = YandexParser;
