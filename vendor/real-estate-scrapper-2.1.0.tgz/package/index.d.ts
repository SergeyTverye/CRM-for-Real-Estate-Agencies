declare class RealEstateScraper {
  constructor(config?: RealEstateScraper.Config);
  /** Creates a scraper. With `browser`, launches a private Chromium (requires optional playwright-core) for sites that block plain HTTP. Call close(). */
  static create(config?: RealEstateScraper.Config & { browser?: true | RealEstateScraper.BrowserOptions }): Promise<RealEstateScraper>;
  /** Closes a browser started by create(); safe to call repeatedly. */
  close(): Promise<void>;
  parsers: {
    cian: RealEstateScraper.CianParser; avito: RealEstateScraper.AvitoParser;
    youla: RealEstateScraper.YoulaParser; yandex: RealEstateScraper.YandexParser;
    onrealt: RealEstateScraper.OnRealtParser; domclick: RealEstateScraper.DomclickParser;
    mirkvartir: RealEstateScraper.MirkvartirParser;
  };
  getAvailableSources(): RealEstateScraper.Source[];
  getCapabilities(): Record<RealEstateScraper.Source, RealEstateScraper.Capabilities>;
  getCapabilities(source: RealEstateScraper.Source): RealEstateScraper.Capabilities;
  buildSearchUrls(query?: RealEstateScraper.Query): Partial<Record<RealEstateScraper.Source, string>>;
  buildSearchLinks(query?: RealEstateScraper.Query): Promise<{ searches: RealEstateScraper.SearchLink[]; errors: RealEstateScraper.PlanError[] }>;
  getDistricts(source: RealEstateScraper.Source, query?: RealEstateScraper.Query): Promise<{ id: string | number; name: string }[]>;
  search(query?: RealEstateScraper.Query): Promise<RealEstateScraper.SearchResult>;
  searchSite(source: RealEstateScraper.Source, query?: RealEstateScraper.Query): Promise<RealEstateScraper.SearchResult & { source: RealEstateScraper.Source }>;
  searchUrl(source: RealEstateScraper.Source, url: string, query?: RealEstateScraper.Query): Promise<RealEstateScraper.SearchResult & { source: RealEstateScraper.Source }>;
  searchPages(query?: RealEstateScraper.Query): AsyncGenerator<RealEstateScraper.Page>;
  report(query?: RealEstateScraper.Query, options?: RealEstateScraper.ReportOptions): Promise<RealEstateScraper.Report>;
}
declare namespace RealEstateScraper {
  type Source = 'cian' | 'avito' | 'youla' | 'yandex' | 'onrealt' | 'domclick' | 'mirkvartir';
  type PropertyType = 'flat' | 'studio' | 'room' | 'house' | 'cottage' | 'townhouse' | 'land' | 'garage' | 'commercial' | 'office' | 'warehouse' | 'retail' | 'freePurpose' | 'industrial' | 'building';
  type CommercialType = 'commercial' | 'office' | 'warehouse' | 'retail' | 'freePurpose' | 'industrial' | 'building';
  type NativeValue = string | number | boolean | null | (string | number | boolean)[];
  interface SourceOptions {
    url?: string;
    params?: Record<string, NativeValue>;
    citySlug?: string;
    regionId?: string | number;
    pageParam?: string;
    pageSize?: number;
    districtIds?: (string | number)[];
    /** Domclick location GUID; automatic mapping covers Moscow. */
    address?: string;
    /** Avito location ID (Moscow: 637640). */
    locationId?: string | number;
    /** Mir Kvartir location scope, e.g. MK_Region|77. */
    locationIds?: string;
    /** Optional Youla city identifier; otherwise resolved from the public city page. */
    cityId?: string;
  }
  interface Query {
    city?: string;
    citySlug?: string;
    regionId?: string | number;
    type?: PropertyType | 'apartment' | 'квартира' | 'квартиры' | 'комната' | 'дом' | 'коттедж' | 'таунхаус' | 'участок' | 'гараж' | 'коммерческая' | 'офис' | 'склад' | 'торговое помещение' | 'псн' | 'производство' | 'здание' | 'студия' | 'нежилое' | 'торговое' | 'офисное' | 'универсальное' | 'универсальное помещение' | 'свободного назначения' | 'производственное' | 'складское';
    category?: 'residential' | 'commercial' | 'жилая' | 'коммерческая';
    /** Commercial uses combined with OR; all remaining filters use AND. */
    types?: (CommercialType | 'торговое' | 'торговое помещение' | 'универсальное' | 'универсальное помещение' | 'свободного назначения' | 'псн' | 'офис' | 'офисное' | 'производство' | 'производственное' | 'склад' | 'складское' | 'коммерческая' | 'нежилое' | 'здание')[];
    floorMode?: 'any' | 'first' | 'notBasement';
    owner?: 'all' | 'owner';
    /** OR within districts; names resolve against the selected source and city. */
    districts?: string[];
    deal?: 'sale' | 'rent' | 'daily' | 'продажа' | 'купить' | 'аренда' | 'снять' | 'посуточно';
    rooms?: number | number[];
    priceMin?: number; priceMax?: number;
    areaMin?: number; areaMax?: number;
    floorMin?: number; floorMax?: number;
    query?: string;
    /** Requires native identifiers/settings; unmapped values raise UNSUPPORTED_FILTER. */
    district?: string; metro?: string | number; sort?: string;
    sources?: Source[];
    page?: number;
    /** Maximum pages per search branch, default 1. */
    maxPages?: number;
    /** Maximum returned listings across all sources. */
    limit?: number;
    sourceOptions?: Partial<Record<Source, SourceOptions>>;
    signal?: AbortSignal;
  }
  interface Listing {
    id?: string | null;
    source: Source;
    title: string;
    price: number | null;
    priceText?: string | null;
    address: string | null;
    rooms: number | null;
    area: number | null;
    floor: number | null;
    url: string;
    images: string[];
    description: string | null;
    phone: string | null;
    city: string | null;
    district: string | null;
    districtSource?: 'projectResolver' | null;
    propertyType?: CommercialType | 'otherCommercial' | null;
    category?: 'commercial' | 'residential' | null;
    deal?: 'sale' | 'rent' | 'daily' | null;
    sellerType?: 'owner' | 'agent' | null;
    floorType?: 'aboveGround' | 'basement' | null;
    /** Cian grouped card: identifier of the card a unit belongs to; the unit URL carries #part-N. */
    parentId?: string;
    /** Unit floor range [from, to] when the site lists a range. */
    floorRange?: [number, number] | null;
    latitude?: number | null;
    longitude?: number | null;
    timestamp: string;
  }
  interface SearchError { source: Source; page: number; code: string; error: string; status?: number; url?: string; types?: PropertyType[]; }
  interface SearchLink { source: Source; types: PropertyType[]; url: string; }
  interface PlanError { source: Source; types?: PropertyType[]; code: string; error: string; }
  interface PageMetadata { source: Source; page: number; url?: string; searchUrl?: string; types?: PropertyType[]; total: number; sourceTotal?: number; truncated?: boolean; hasNext: boolean | null; nextUrl: string | null; errors: SearchError[]; }
  interface Page extends PageMetadata { results: Listing[]; }
  interface SearchResult { query: Query; timestamp: string; total: number; results: Listing[]; errors: SearchError[]; pages: PageMetadata[]; partial: boolean; }
  interface TransportRequest {
    url: string; method: string; headers: Record<string, string>; timeout: number; signal?: AbortSignal;
    /** Open a same-origin HTML page, then fetch the API from that page. */
    browser?: { url: string; waitForSelector?: string };
    [key: string]: unknown;
  }
  interface TransportResponse { data: unknown; status?: number; url?: string; headers?: Record<string, string>; }
  type Transport = (request: TransportRequest) => Promise<TransportResponse | string>;
  interface Config {
    delay?: number;
    /** Additional attempts after the initial request. Zero disables retries. */
    maxRetries?: number;
    timeout?: number;
    proxy?: string | { protocol?: string; host: string; port?: number; auth?: { username: string; password: string } };
    headers?: Record<string, string>;
    transport?: Transport;
    sourceConfigs?: Partial<Record<Source, Omit<Config, 'sourceConfigs'>>>;
    selectors?: Partial<Record<Source, Partial<Record<'card' | 'link' | 'title' | 'price' | 'address', string>>>>;
  }
  interface Capabilities {
    source: Source; nativeUrl: boolean; nativeParams: boolean; pagination: string;
    unifiedFilters: string[]; note: string;
    localFilters?: string[];
    nativeMultiType?: boolean;
    splitTypesInReport?: boolean;
    commercial?: boolean;
    commercialTypes?: CommercialType[];
    deals?: ('sale' | 'rent' | 'daily')[];
    automaticCities?: string[];
  }
  class ScraperError extends Error { code: string; source?: Source; status?: number; url?: string; }
  class BaseParser {
    constructor(config?: Config);
    sourceName: Source;
    baseUrl: string;
    buildSearchUrl(query?: Query): string;
    extractData(query?: Query): Promise<Listing[]>;
    searchPage(query?: Query): Promise<Omit<Page, 'total' | 'errors'>>;
    parsePage(html: unknown, url: string, query: Query): { results: Listing[]; nextUrl: string | null; hasNext: boolean; sourceTotal?: number };
    fetch(url: string, options?: Record<string, unknown>): Promise<unknown>;
    parsePrice(value: string | number | null): number | null;
    getCapabilities(): Capabilities;
    saveToJson(data: unknown, filename: string): string;
  }
  class CianParser extends BaseParser {}
  class AvitoParser extends BaseParser {
    getDistricts(query?: Query): Promise<{ id: number; name: string }[]>;
    fetchDetails(item: Listing, query?: Query): Promise<Listing>;
  }
  class YoulaParser extends BaseParser { fetchDetails(item: Listing, query?: Query): Promise<Listing>; }
  class YandexParser extends BaseParser {}
  class OnRealtParser extends BaseParser {
    /** Resolves requested district names; query must include district/districts. Not a full catalog. */
    getDistricts(query?: Query): Promise<{ id: string; name: string }[]>;
  }
  class DomclickParser extends BaseParser {}
  class MirkvartirParser extends BaseParser {
    getDistrictCatalog(query?: Query): Promise<{ id: string; name: string }[]>;
    resolveDistrictIds(names: string[], query?: Query): Promise<string[]>;
  }
  /** The caller retains ownership of context and browser. No Playwright dependency is loaded. */
  function createBrowserTransport(options: {
    context: { newPage(): Promise<any>; request?: any };
    waitUntil?: 'load' | 'domcontentloaded' | 'networkidle' | 'commit';
    waitForSelector?: string | ((url: string) => string | undefined);
    timeout?: number;
    /** Pause after navigation, ms. */
    settleMs?: number;
    /** Visit each origin's home page once before the first request. */
    warmup?: boolean;
  }): Transport;
  interface ReportOptions {
    /** Maximum detail pages per source; zero disables details. Default 30. */
    detailLimit?: number;
    /** Maximum candidates per search branch before verification. Defaults to query.limit or 100. */
    candidateLimit?: number;
    /** Optional project-provided district lookup; no public geocoder is called automatically. */
    districtResolver?: (item: Listing, query: Query) => string | null | Promise<string | null>;
  }
  interface Verification {
    status: 'matched' | 'rejected' | 'unknown';
    rejected: string[]; unknown: string[];
    evidence: Record<string, { via: 'sourceFilter' | 'listing' | 'projectResolver'; value?: unknown; detail?: string }>;
  }
  interface ReportListing extends Listing { verification: Verification; }
  interface SourceReport {
    source: Source; status: 'ok' | 'partial' | 'blocked' | 'unsupported' | 'notApplicable' | 'error';
    matched: number; rejected: number; unknown: number; inspected: number; detailsFetched: number;
    scanComplete: boolean;
    /** Requested uses the site does not publish; NOT_APPLICABLE does not become a report error. */
    notOffered: PropertyType[];
    searches: { url: string; types?: PropertyType[]; localFilters: string[] }[];
    errors: { source: Source; code: string; error: string; page?: number; url?: string; status?: number; types?: PropertyType[] }[];
    pages: PageMetadata[];
    filterCoverage: { types: PropertyType[]; nativeFilters: string[]; localFilters: string[] }[];
  }
  interface Report {
    query: Query; timestamp: string; total: number; results: ReportListing[];
    unresolved: ReportListing[]; sources: SourceReport[];
    summary: { requestedSources: number; respondedSources: number; sourcesWithMatches: number;
      /** Sources that publish this kind of property (excludes notApplicable). */
      applicableSources: number;
      /** respondedSources > applicableSources / 2 */
      majorityResponded: boolean; matched: number; returned: number; rejected: number; unknown: number; complete: boolean };
  }
  function renderReport(report: Report): string;
  /** Semicolon-separated UTF-8 CSV (with BOM) for Excel: confirmed rows and rows that need checking. */
  function renderCsv(report: Report): string;
  interface BrowserOptions {
    /** Sources routed through the browser. Default: cian, avito. */
    sources?: Source[];
    executablePath?: string;
    /** Installed browser channel, e.g. 'chrome' or 'msedge'. */
    channel?: string;
    headless?: boolean;
    /** Default UA uses the launched Chromium version. */
    userAgent?: string;
    /** Outgoing browser proxy; does not guarantee access to a blocked source. */
    proxy?: string | { server: string; username?: string; password?: string };
    timeout?: number;
    /** Pause after navigation for client-side rendering, ms. Default 1500. */
    settleMs?: number;
    waitForSelector?: string | ((url: string) => string | undefined);
    launchOptions?: Record<string, unknown>;
  }
  function launchBrowserTransport(options?: BrowserOptions): Promise<{ transport: Transport; context: any; browser: any; close(): Promise<void> }>;
  const RealEstateScraper: typeof import('./index');
}
export = RealEstateScraper;
