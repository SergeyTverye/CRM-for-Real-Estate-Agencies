# API

CommonJS: `const RealEstateScraper = require('real-estate-scrapper')`. Контракт типов — [index.d.ts](index.d.ts), быстрый старт и матрица площадок — [README.md](README.md).

## Создание и транспорт

`new RealEstateScraper(config = {})` не запускает браузер. Настройки по умолчанию: `delay: 1000` мс, `maxRetries: 2` дополнительных попытки, `timeout: 30000` мс. Принимаются `headers`, `proxy`, `transport`, `selectors` и `sourceConfigs`. Последний переопределяет настройки отдельно для каждой площадки:

```js
const scraper = new RealEstateScraper({
  timeout: 20000,
  sourceConfigs: { cian: { transport: cianTransport }, avito: { maxRetries: 0 } }
});
```

`transport(request)` получает axios-совместимые параметры, в том числе `url`, `method`, `headers`, `timeout`, `signal`, при необходимости `data`. Возвращает промис с `{ data, status?, url?, headers? }` или строкой. Формат `data` зависит от источника: HTML, JSON и т. п. Сохраняйте HTTP-статус и конечный URL, чтобы ограничения и редиректы обрабатывались корректно.

`await RealEstateScraper.create({ ...config, browser: true | options })` запускает приватный Chromium через опциональный `playwright-core`, устанавливает его транспорт для `browser.sources` (по умолчанию `['cian', 'avito']`). При отсутствии `browser` работает как обычный конструктор. Опции:

| Поле | Значение |
|---|---|
| `sources` | Источники для браузерного транспорта |
| `channel`, `executablePath` | Например, `channel: 'chrome'` для установленного Chrome либо путь к исполняемому файлу |
| `headless`, `userAgent` | По умолчанию `headless: true`, настольный UA с версией запущенного Chromium; явный userAgent сохраняется |
| `proxy` | Строка сервера либо `{ server, username?, password? }` |
| `timeout`, `settleMs` | 45000 и 1500 мс; timeout транспорта используется, если его нет в запросе |
| `waitForSelector` | CSS-селектор или функция URL → селектор / `undefined` |
| `launchOptions` | Дополнительные опции Playwright launch; args дополняют обязательный флаг AutomationControlled |

У `browser: true` не задан канал: нужен доступный Chromium Playwright; для установленного Chrome укажите `{ channel: 'chrome' }`. В `finally` вызывайте `await scraper.close()`: закрывает запущенный через `create()` браузер, повторный вызов безопасен. За транспорт, переданный вручную, отвечает вызывающий проект.

Экспорты:

- `createBrowserTransport({ context, waitUntil?, waitForSelector?, timeout?, settleMs?, warmup? })` использует ваш Playwright BrowserContext и не загружает Playwright самостоятельно. По умолчанию `waitUntil='domcontentloaded'`, `timeout=30000`, `settleMs=0`. Без browser metadata GET открывает страницу, остальные методы используют `context.request.fetch`, разделяя cookies. При `request.browser={ url, waitForSelector? }` сначала открывается HTML на том же origin, затем выполняется API fetch из страницы с `credentials: 'same-origin'`. При неготовой/заблокированной HTML-странице возвращается её реальный ответ. `warmup` посещает главную каждого origin один раз, успешный seed также отмечает origin прогретым. Контекст/браузер остаются во владении проекта.
- `launchBrowserTransport(options?)` возвращает `{ transport, context, browser, close }`. Самостоятельный вызов требует закрыть результат через его `close()`. `sources` используется только фабрикой `RealEstateScraper.create()`.
- `renderReport(report)` возвращает HTML; `renderCsv(report)` — CSV с `;`, BOM, CRLF, совпадениями и непроверенными строками. Начальные символы формул в ячейках экранируются. Запись файлов выполняет вызывающий код.

Авито задаёт browser metadata сам: HTML-выдача → API fetch со страницы. На текущем IP 5 ноября HTML уже возвращает HTTP 429 «проблема с IP» / hCaptcha; это `ACCESS_BLOCKED`, не пустой результат. Для нового живого подтверждения нужен разблокированный исходящий IP. Настройка `create({ browser: { channel: 'chrome', proxy: { server: 'http://proxy-host:8080', username: 'user', password: 'password' } } })` передаёт proxy в запуск браузера; доступ через произвольный proxy не гарантируется. Исследование: [avito-browser-investigation.md](research/avito-browser-investigation.md).

## Запрос

| Поля | Семантика |
|---|---|
| `category`, `type` | `residential`/`commercial`; тип по умолчанию `flat`, при коммерческой категории — `commercial` |
| `types` | Непустой массив коммерческих назначений через ИЛИ: `office`, `retail`, `freePurpose`, `industrial`, `warehouse`, `building`, либо один `commercial` |
| `deal` | `sale` (по умолчанию), `rent`, `daily`; посуточная коммерция запрещена валидацией |
| `city`, `citySlug`, `regionId` | Город, slug, ID региона; город не подставляется автоматически |
| `districts`, `district` | Массив названий через ИЛИ или одно название; вместе запрещены |
| `priceMin/Max`, `areaMin/Max`, `floorMin/Max` | Неотрицательные числовые границы; рубли, м², этаж. Min ≤ Max |
| `floorMode` | `any`, `first`, `notBasement`; противоречие диапазону запрещено |
| `owner` | `all` или `owner` |
| `rooms` | Число / массив целых 0–20, только квартира/студия; 0 означает студию |
| `query`, `metro`, `sort` | Текст / дополнительные фильтры, только где сопоставлены; иначе `UNSUPPORTED_FILTER` |
| `sources` | Источники в порядке обхода; по умолчанию все семь, повторы удаляются |
| `page`, `maxPages`, `limit` | Положительные целые; page=1, maxPages=1; limit по умолчанию отсутствует |
| `signal` | `AbortSignal` |
| `sourceOptions` | Настройки конкретных площадок из таблицы ниже |

Допустимые `type`: `flat`, `studio`, `room`, `house`, `cottage`, `townhouse`, `land`, `garage` и коммерческие типы выше. Принимаются русские псевдонимы типов и сделок (см. декларации). `types` автоматически задаёт коммерческую категорию; все условия вне массивов ИЛИ соединяются через И. Неизвестные поля и противоречия вызывают `TypeError`.

`sourceOptions[source]`:

| Поле | Назначение |
|---|---|
| `url` | Проверенный HTTPS URL домена площадки; сохраняет нативные настройки, но не отменяет проверку переданных единых фильтров |
| `params` | Нативные query-параметры: scalar, массив повторений или `null` для удаления. Приоритет относительно единых условий зависит от парсера; избегайте конфликтов |
| `citySlug`, `regionId` | География конкретной площадки |
| `districtIds` | Массив ID районов конкретной площадки; обходит разрешение названий общим резолвером |
| `pageParam`, `pageSize` | Особенности пагинации; Домклик использует только `offset`, размер 1–100 (по умолчанию 20) |
| `address` | GUID локации Домклика; автоматическое сопоставление — Москва |
| `locationId` | ID Авито, Москва — `637640` |
| `locationIds` | Область Мира Квартир, например `MK_Region|77`; автоматическое сопоставление — Москва |
| `cityId` | ID города Юлы; иначе извлекается из публичной страницы |

## Методы поиска

| Метод | Результат |
|---|---|
| `getAvailableSources()` | `cian`, `avito`, `youla`, `yandex`, `onrealt`, `domclick`, `mirkvartir` |
| `getCapabilities(source?)` | Обзор фильтров, нативных URL/params, пагинации; необязательные `localFilters`, `nativeMultiType` и поля коммерческих возможностей |
| `buildSearchUrls(query = {})` | Синхронный `{ source: url }`; не разрешает районы по сети и не разбивает назначения, может выбросить ошибку |
| `buildSearchLinks(query = {})` | `{ searches: [{ source, types, url }], errors: [{ source, types?, code, error }] }`; разрешает районы, разбивает назначения там, где нет nativeMultiType |
| `getDistricts(source, query = {})` | `{ id, name }[]` из справочника Циана, Яндекса, Домклика, Авито; у OnRealt — подсказки по обязательным запрошенным названиям |
| `search(query = {})` | Объединённые кандидаты и ошибки |
| `searchSite(source, query = {})` | Формат search плюс поле `source` |
| `searchUrl(source, url, query = {})` | searchSite с `sourceOptions[source].url` |
| `searchPages(query = {})` | AsyncGenerator страниц; ошибки источников представлены страницами с `errors` |
| `report(query = {}, options = {})` | Проверенный отчёт, описан ниже |

`search` и `buildSearchLinks` требуют представить все переданные ограничения на стороне площадки. Только `report()` применяет `reportPlan` парсера: удаляет объявленные локальными ограничения из поискового запроса и проверяет их по объявлению. Например, этаж Юлы и собственник Авито требуют отчёта. Capabilities содержит обзор, а `filterCoverage` — план конкретного отчёта; отдельные note/localFilters в capabilities могут отставать от текущей интеграции районов.

Формат `search()`: `{ query, timestamp, total, results, errors, pages, partial }`. `total` — число возвращённых строк; `partial` истинно только при наличии и результатов, и ошибок. `query` нормализован, `signal` исключён. Пагинация последовательная; `maxPages` — на ветвь, `limit` — общий. Дедупликация по source + URL. У Юлы вместо произвольного номера нужен курсор из предыдущего ответа; используйте `maxPages`/`searchPages`.

`pages[]`: `source`, `page`, `total`, `hasNext`, `nextUrl`, `errors`; дополнительно `url`, `searchUrl`, `types`, `sourceTotal`, `truncated`. `sourceTotal` — счётчик площадки, если известен. При ошибке `hasNext=null`; достижение бюджета не означает `hasNext=false`. Ошибка содержит `{ source, page, code, error, status?, url? }`, ошибки планирования могут содержать `types`.

Объявления имеют `source`, `title`, `url`, `images`, `timestamp`, цену/площадь/этаж и другие поля [Listing](index.d.ts). Неизвестные числовые поля — `null`; `address`, `description` допускают `null`, необязательный `priceText` — тоже. Дополнительные коммерческие поля: `category`, `propertyType`, `deal`, `sellerType`, `floorType`, `district`, координаты. Циан раскрывает групповые карточки: `parentId`, `floorRange`, URL с `#part-N`; это отдельные помещения.

## Районы

Нативный фильтр районов поддерживают `cian`, `yandex`, `domclick`, `avito`, `onrealt`, `mirkvartir`; локальная проверка района в отчёте нужна только `youla`. Общий `lib/districts.js` разрешает имена, справочники кэшируются. Неверное или неоднозначное имя — ошибка разрешения; наличие `sourceOptions[source].districtIds` пропускает поиск имён.

OnRealt `getDistricts({ city: 'Москва', districts: ['Арбат', 'Тверской'] })` разрешает именно запрошенные названия через публичную геоподсказку (до 20 вариантов на запрос), а не возвращает полный каталог. Без district/districts — `UNSUPPORTED_FILTER`. ID 11/5 передаются как `location={"4":["11","5"]}`; прямой параметр district площадка игнорирует. Другие группы нативного location сохраняются. Для офисов этаж нативный, для остальных коммерческих назначений этажные условия проверяются локально. HTTP 404 с точным маркером «Объявлений не найдено.» даёт пустую страницу; активная проверка робота — `ACCESS_BLOCKED`, неизвестный 404 — `FETCH_FAILED`. Этаж `-1 / 6` сохраняется как `floor=-1`, `floorType='basement'`.

Мир Квартир разрешает названия через собственный каталог: общий резолвер вызывает `resolveDistrictIds()`. Например, Арбат/Тверской передаются как `districts=81,164`. Можно также подготовить ID явно:

```js
const districtIds = await scraper.parsers.mirkvartir.resolveDistrictIds(
  ['Арбат', 'Тверской'], { city: 'Москва' }
);
const report = await scraper.report({
  city: 'Москва', category: 'commercial', type: 'office', deal: 'sale',
  sources: ['mirkvartir'], districts: ['Арбат', 'Тверской'],
  sourceOptions: { mirkvartir: { districtIds } }
});
```

`MirkvartirParser.getDistrictCatalog(query?)` возвращает `{ id: string, name: string }[]`, `resolveDistrictIds(names, query?)` — `string[]`. Обычные search/report/buildSearchLinks разрешают имена через этот хук автоматически; getDistricts для Мира Квартир пока не делегирует getDistrictCatalog — вызывайте каталог парсера.

`report(query, { districtResolver: async (listing, query) => districtNameOrNull })` вызывает ваш справочник только при отсутствующем районе и наличии условия на район. Возврат: непустая строка или `null`; допускается синхронная функция. Ошибка учитывается как `DISTRICT_LOOKUP_FAILED`. Такой callback дополняет объявление, но не исправляет ошибку планирования нативного запроса.

## Проверенный отчёт

Опции: `candidateLimit` — положительное целое, по умолчанию `query.limit ?? 100`; `detailLimit` — неотрицательное целое, по умолчанию 30, 0 отключает детали. Лимит кандидатов применяется к каждому вызову searchSite внутри отчёта; у OnRealt/Мира Квартир это отдельная ветвь на назначение. `detailLimit` считает попытки на источник. `query.limit` ограничивает только итоговые совпадения; `unresolved` не обрезается.

Поля: `{ query, timestamp, total, results, unresolved, sources, summary }`.

- `results`: `verification.status='matched'`; `unresolved`: `unknown`. Отклонённые записи представлены счётчиками.
- `verification`: `status`, массивы `rejected`/`unknown` с именами условий, `evidence`. Источники доказательства: `listing`, `sourceFilter`, `projectResolver`; возможны `value`, `detail`.
- Известное противоречие объявлению отклоняет объект даже при нативном фильтре. Если поле неизвестно, нативный фильтр может дать `sourceFilter`; у локального условия это `unknown`. Подвал/цоколь в описании может исключить объявление с положительным номером этажа.

`sources[]` содержит счётчики `matched`, `rejected`, `unknown`, `inspected`, `detailsFetched`, а также `searches`, `pages`, `errors`, `filterCoverage`, `notOffered`, `scanComplete`, `status`. В `searches` — фактически полученные URL, типы и `localFilters`; `filterCoverage` содержит типы, `nativeFilters`, `localFilters` для каждого плана.

Статус определяется по успешным страницам: `ok` — без ошибок/unknown; `partial` — с ошибками или unknown. Без успешных страниц: `notApplicable` — только отсутствующие категории без ошибок; затем `blocked` при ACCESS_BLOCKED; `unsupported`, если все ошибки UNSUPPORTED_FILTER/DISTRICT_RESOLUTION_REQUIRED; иначе `error`. Успешный пустой ответ тоже считается ответом.

Мир Квартир не предлагает отдельные `industrial`/`building`: `NOT_APPLICABLE` из поиска переносится в `sources[].notOffered`, не в ошибки отчёта, и сам по себе не ухудшает статус. При успешных страницах остальных категорий без ошибок/unknown источник — `ok`; при запросе только отсутствующих — `notApplicable`.

`summary`:

| Поле | Значение |
|---|---|
| `requestedSources` | Число запрошенных площадок |
| `respondedSources` | Число `ok` и `partial` |
| `applicableSources` | Все, кроме `notApplicable` |
| `sourcesWithMatches` | Площадки с matched > 0 до лимита вывода |
| `majorityResponded` | `respondedSources > applicableSources / 2` |
| `matched`, `returned` | Совпадения до/после limit; `returned = total = results.length` |
| `rejected`, `unknown` | Сумма отклонений; число unresolved |
| `complete` | Каждый источник — notApplicable либо ok с scanComplete |

`scanComplete` требует отсутствия ошибок/unknown и у последних страниц ветвей `hasNext=false` без `truncated`. `ok` и ответ большинства не гарантируют завершённый обход рынка. Данные/права продавца независимо не подтверждаются, если доказательство — только `sourceFilter`.

Итоговый живой прогон 5 ноября с Басманным/Нагорным: 6/7 ответивших, 186 совпадений и 2 unknown, Авито blocked. Внешний consumer без браузера: пять HTTP-площадок, 192 совпадения, TS strict успешен. Бюджеты и наборы источников различаются; выборочная сверка страниц выявила ограничения и не подтверждает все результаты. Подробности, 115 тестов итоговой проверки и ссылки на QA — в [validation.md](examples/validation.md).

## Прямые парсеры, ошибки и CLI

Экспортированы `BaseParser`, `CianParser`, `AvitoParser`, `YoulaParser`, `YandexParser`, `OnRealtParser`, `DomclickParser`, `MirkvartirParser`, `ScraperError` и сам `RealEstateScraper`. Прямые методы: `buildSearchUrl`, `searchPage`, `extractData`, `parsePage(data, url, query)`, `fetch`, `parsePrice`, `getCapabilities`, `saveToJson`. `parsePage` принимает `unknown`, так как часть парсеров обрабатывает JSON. `extractData` не сохраняет частичный массив при ошибке поздней страницы; для этого используйте общий поиск. `fetchDetails` реализован у Юлы и Авито, отчёт вызывает его в пределах бюджета.

`selectors: { source: { card, link, title, price, address } }` меняет общие DOM-селекторы, но не схемы специализированных JSON/SSR-парсеров. `ScraperError` содержит `code`, при наличии `source`, `status`, `url`. Коды перечислены в [README](README.md#ошибки-и-ограничения). Отмена через `signal` прерывает операцию с `ABORTED`; неверный запрос/источник — `TypeError`. Проверяйте ошибки и при непустом результате.

`npm run report -- query.json output-directory --browser[=path]` записывает JSON, HTML и CSV. Без пути выбирается Chrome. `--cdp=http://127.0.0.1:9222` использует существующий браузер только для Циана, его API запрашивается HTTP; `--browser` имеет приоритет. CLI закрывает своё подключение/созданный браузер в finally. Точные значения по умолчанию и примеры — в README.

`require()` не делает запросов и не пишет файлов. Пакет включает код, декларации, README/API, примеры и scripts; исследовательские данные и отчёты не включены. Основной импорт типизирован, отдельные `parsers/*` предназначены для CommonJS.
