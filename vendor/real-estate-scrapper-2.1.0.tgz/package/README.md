# Real Estate Scraper

CommonJS-библиотека Node.js ≥ 20.19 для поиска коммерческой недвижимости на семи площадках и встраивания результатов в CRM или сайт риелтора. Имя пакета: `real-estate-scrapper`. Есть декларации TypeScript.

## Быстрый старт

Установите библиотеку в проект одним из способов:

```powershell
npm install D:/Real-Estate-Scrapper
# Либо из подготовленного архива:
npm install ./real-estate-scrapper-2.1.0.tgz
# Опционально для браузерного режима Циана/Авито; Chrome должен быть установлен:
npm install playwright-core
```

Пример CommonJS: нежилые помещения с пятью назначениями через ИЛИ, ценой, площадью, районами, этажом и продавцом.

```js
const fs = require('node:fs');
const RealEstateScraper = require('real-estate-scrapper');

async function main() {
  const scraper = await RealEstateScraper.create({
    delay: 500, maxRetries: 1, timeout: 30000,
    browser: { channel: 'chrome' } // Опционально; по умолчанию для cian и avito.
  });
  try {
    const report = await scraper.report({
      city: 'Москва', category: 'commercial',
      types: ['retail', 'freePurpose', 'office', 'industrial', 'warehouse'],
      deal: 'sale', floorMode: 'first', // Или 'notBasement': без подвала/цоколя.
      owner: 'owner',                 // Или 'all': все продавцы.
      priceMin: 10000000, priceMax: 100000000,
      areaMin: 50, areaMax: 150,
      districts: ['Арбат', 'Тверской'],
      sources: ['cian', 'avito', 'youla', 'yandex', 'onrealt', 'domclick', 'mirkvartir'],
      maxPages: 2, limit: 100
    }, { candidateLimit: 30, detailLimit: 20 });

    fs.writeFileSync('report.json', JSON.stringify(report, null, 2), 'utf8');
    fs.writeFileSync('report.html', RealEstateScraper.renderReport(report), 'utf8');
    fs.writeFileSync('report.csv', RealEstateScraper.renderCsv(report), 'utf8');
    console.log(report.summary);
  } finally {
    await scraper.close();
  }
}
main().catch(error => { console.error(error); process.exitCode = 1; });
```

Для HTTP без запуска браузера используйте `new RealEstateScraper(config)` или `create(config)` без `browser`. В итоговом прогоне с районами **5 ноября 2026, Москва** ответили 6 из 7 площадок: 186 совпадений и 2 требуют проверки; Авито — `blocked`. Внешний consumer из tgz получил 192 совпадения на пяти HTTP-площадках без браузера, TypeScript strict прошёл. Это разные ограниченные выборки, не полный обход рынка; подробности и ограничения сверки со страницами — в [validation.md](examples/validation.md).

## Площадки и фильтры

Таблица относится к коммерческой продаже/аренде и `report()`. Известные значения объявления всегда проверяются на противоречия условиям, включая нативные фильтры.

| Площадка | На стороне площадки | Локально в отчёте | Браузер и особенности |
|---|---|---|---|
| Циан (`cian`) | Назначения ИЛИ, сделка, цена, площадь, этаж, собственник, районы | Проверка известных полей | При блокировке HTTP нужен браузер. Групповые карточки раскрываются в помещения с URL `#part-N`, `parentId`, `floorRange` |
| Авито (`avito`) | Коммерческий JSON endpoint, назначения ИЛИ, сделка, цена, площадь, первый этаж, районы | Собственник, `floorMin/Max`, `notBasement` | Браузер открывает HTML-выдачу, затем вызывает API через fetch страницы. На текущем IP — 429 / hCaptcha. «Частное лицо» ≠ собственник; принимается системный бейдж |
| Юла (`youla`) | Назначения ИЛИ, сделка, собственник, цена, площадь, текст | Районы, этаж и диапазон этажей; детали дополняют поля | HTTP GraphQL без аккаунта, последовательная пагинация курсором; произвольная страница без курсора невозможна |
| Яндекс (`yandex`) | Назначения ИЛИ, сделка, цена, площадь, этаж, собственник, районы | Проверка известных полей | HTTP; возможна капча |
| OnRealt (`onrealt`) | Отдельный поиск на назначение; сделка, цена, площадь, собственник, районы; этаж для офиса | Этаж остальных назначений | HTTP. 404 с точным маркером «Объявлений не найдено.» — пустой результат; `-1 / 6` сохраняется как `floor=-1`, `floorType=basement` |
| Домклик (`domclick`) | Пять назначений ИЛИ, сделка, цена, площадь, этаж, собственник, районы | Проверяются поля и описание: API может искажать знак этажа | Публичный JSON API по HTTP, браузер не обязателен; пагинация `offset` |
| Мир Квартир (`mirkvartir`) | Офис, торговля, ПСН, склад отдельными поисками; сделка, цена, площадь, этаж, собственник; районы через собственный каталог | Поля выдачи и явные данные района | HTTP, разделы `cre`/`arendacre`. Категории производства и здания отсутствуют → `notOffered` |

Назначения в `types` и районы в `districts` объединяются через **ИЛИ**, остальные условия через **И**. `commercial` означает любое нежилое назначение, его нельзя смешивать с конкретными типами. Русские названия (`торговое`, `псн`, `офисное`, `производственное`, `склад`) нормализуются. Произвольная фраза в фильтры не преобразуется. `floorMode`: `first` — первый этаж, `notBasement` — от первого без подвала/цоколя, `any` — без ограничения. Цена — в рублях, площадь — в м²; период аренды сверяйте с площадкой.

| Районы | Источники |
|---|---|
| Нативный фильтр | `cian`, `yandex`, `domclick`, `avito`, `onrealt`, `mirkvartir` |
| Локальная проверка в отчёте | Только `youla`; без данных район останется неизвестным |

Имена разрешаются автоматически при search/report/buildSearchLinks. Известные ID задаются в `sourceOptions[source].districtIds`. Пример справочника: `await scraper.getDistricts('domclick', { city: 'Москва' })`. OnRealt требует запрошенные названия в `districts`: это подсказки, а не полный каталог; фильтр передаётся как `location={"4":["11","5"]}` (Арбат/Тверской). Мир Квартир использует `resolveDistrictIds()`, например `districts=81,164` для Арбата/Тверского. Подробности — в [API.md](API.md). Метро или улица не заменяют район. Можно передать свой `districtResolver`; сторонний геокодер автоматически не вызывается.

Автоматическая коммерческая география Домклика, Авито и Мира Квартир проверена для Москвы. Для других городов нужны соответственно `sourceOptions.domclick.address` (GUID), `avito.locationId`, `mirkvartir.locationIds` либо проверенный URL площадки. ID разных сайтов невзаимозаменяемы. `getCapabilities()` даёт обзор; сочетание фильтров уточняйте по таблице и фактическому `filterCoverage`: некоторые пояснения capabilities пока отстают от реализации районов.

## Как читать отчёт

- `results` — совпадения, `unresolved` — кандидаты с неизвестными обязательными условиями; отклонённые объекты представлены счётчиками `rejected`.
- `verification.evidence`: `listing` — поле объявления, `sourceFilter` — применён фильтр площадки, `projectResolver` — результат вашего справочника. `sourceFilter` не является независимой проверкой права собственности. Известное противоречие отклоняет объект; отсутствующее локально проверяемое поле остаётся неизвестным.
- `sources[].filterCoverage` показывает `nativeFilters` и `localFilters`. Локальные условия удаляются из запроса к площадке и проверяются отчётом. Ссылка из `searches` в таком случае ведёт на кандидатов.
- `summary.respondedSources` считает `ok`/`partial`; `applicableSources` исключает `notApplicable`; `majorityResponded` означает строго `respondedSources > applicableSources / 2`.
- `summary.matched` — до лимита вывода; `returned = total = results.length`. `unknown` — размер `unresolved`. `complete` требует завершённых обходов всех применимых площадок.

| Статус источника | Значение |
|---|---|
| `ok` | Есть успешная страница, нет ошибок и неизвестных кандидатов; обход может ещё продолжаться |
| `partial` | Есть успешная страница, но также ошибки или неизвестные кандидаты |
| `blocked` | Нет успешных страниц, есть `ACCESS_BLOCKED` |
| `unsupported` | Нет успешных страниц; все ошибки — `UNSUPPORTED_FILTER` / `DISTRICT_RESOLUTION_REQUIRED` |
| `notApplicable` | Нет успешных страниц и ошибок, запрошенные категории не предлагаются |
| `error` | Другой сбой без успешных страниц |

`notOffered` перечисляет отсутствующие категории даже при `ok` по остальным. `scanComplete` учитывает ошибки, неизвестные данные, `hasNext` и обрезку страницы. `maxPages` ограничивает страницы каждой поисковой ветви; `candidateLimit` (по умолчанию `query.limit` или 100) — кандидатов на вызов поиска в отчёте, а у источников с разбиением — на назначение; `detailLimit` (30) — попытки загрузки деталей на источник, 0 отключает их. `limit` обрезает итоговые совпадения, но не `unresolved`.

HTML показывает отчёт; CSV включает совпадения и требующие проверки строки, разделитель `;`, UTF-8 BOM для Excel. JSON сохраняет метаданные и доказательства.

## CLI

Из репозитория после `npm install`:

```powershell
npm run report
npm run report -- examples/commercial-report.json data/my-report --browser
npm run report -- examples/commercial-report.json data/my-report "--browser=C:/Program Files/Google/Chrome/Application/chrome.exe"
npm run report -- examples/commercial-report.json data/my-report --cdp=http://127.0.0.1:9222
npm run report -- examples/commercial-districts.json data/final-report "--browser=C:/Program Files/Google/Chrome/Application/chrome.exe"
```

По умолчанию запрос — `examples/commercial-report.json`, каталог — `data/commercial-report`. Всегда записываются `report.json`, `report.html`, `report.csv`. `--browser[=path]` запускает собственный Chromium для Циана/Авито; без пути выбирается установленный Chrome. `--cdp=` подключает существующий браузер **только для Циана**, его `/api/` остаётся на HTTP. Оба режима требуют `playwright-core`; при одновременных флагах приоритет у `--browser`. CLI использует `detailLimit: 20`, `candidateLimit: 30`.

## Ошибки и ограничения

Проверяйте `sources[].errors` даже при наличии совпадений. `search()` возвращает ошибки в `errors`, а прямой парсер отклоняет промис. Неверный запрос и неизвестный источник вызывают `TypeError`; отмена через `AbortSignal` прерывает операцию с `ABORTED`.

| Код | Причина |
|---|---|
| `ACCESS_BLOCKED` | Капча / ограничение доступа, в том числе HTTP 401/403/429 и Авито 439 |
| `FETCH_FAILED`, `SEARCH_FAILED`, `DETAIL_FAILED` | Запрос или операция не выполнены; смотрите сообщение и URL |
| `PARSE_FAILED`, `INVALID_RESPONSE`, `API_RESPONSE_FAILED` | Нераспознанная разметка, формат или схема API |
| `UNSUPPORTED_FILTER` | Нет проверенного соответствия фильтру |
| `DISTRICT_RESOLUTION_REQUIRED`, `DISTRICT_NOT_FOUND`, `DISTRICT_LOOKUP_FAILED` | Нужны ID района, имя не найдено/неоднозначно или справочник недоступен |
| `LOCATION_REQUIRED`, `LOCATION_NOT_FOUND` | Не задана или не разрешена локация |
| `CURSOR_REQUIRED`, `PAGINATION_FAILED` | Нет нужного курсора или нарушена пагинация |
| `LISTING_UNAVAILABLE` | Детальная карточка Юлы удалена, архивирована или продана |
| `INVALID_URL` | URL вне HTTPS-домена площадки или содержит credentials |
| `NOT_APPLICABLE` | Категория отсутствует; в `report()` переносится в `notOffered` |
| `ABORTED` | Операция отменена |

Авито 5 ноября на текущем IP возвращает 429 «Доступ ограничен: проблема с IP» / hCaptcha уже на HTML-выдаче; после блока API не вызывается. Для следующего живого подтверждения нужен другой, разблокированный исходящий IP. В `create()` можно задать `browser: { channel: 'chrome', proxy: { server: 'http://proxy-host:8080', username: 'user', password: 'password' } }`. Это настройка подключения, не гарантия доступа; подробности — в [исследовании](research/avito-browser-investigation.md).

Выборка ограничена бюджетом; дедупликация работает по источнику и URL, между площадками один объект может повторяться. Доступность, поля, разметка и API меняются. Сверка 15 объектов со страницами выявила ошибку знака этажа OnRealt (исправлена в текущем коде) и риск неверного этажа Юлы из описания комплекса; часть полей и страниц недоступна для проверки. Отсутствующие значения могут быть `null`. Коммерческое назначение объявления не подтверждает юридическую возможность использования помещения.

Методы поиска, параметры транспорта и типы: [API.md](API.md), [index.d.ts](index.d.ts). История и доказательства прогонов: [examples/validation.md](examples/validation.md).
